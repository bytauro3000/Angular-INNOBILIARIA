import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ContratoResponseDTO } from '../dto/contratoreponse.dto';
import { ContratoListItemDTO } from '../dto/contrato-list-item.dto';
import { TransferenciaResponseDTO } from '../dto/Transferenciaresponse.dto';
import { ContratoRequestDTO } from '../dto/contratorequest.dto';
import { environment } from '../../environments/environment';

export interface ImpactoEdicionDTO {
  tieneLetras:    boolean;
  tienePagos:     boolean;
  cantidadLetras: number;
  cantidadPagos:  number;
}

export interface LoteVendidoDTO {
  manzana: string;
  numeroLote: string;
  area: number;
  costoVenta: number;
  cliente: string;
  vendedor: string;
  idVendedor?: number;
  fechaContrato: string;
  estadoContrato: string;
  idContrato: number;
}

export interface ProgramaVendidoDTO {
  nombrePrograma: string;
  lotes: LoteVendidoDTO[];
  totalPrograma: number;
  cantidadLotes: number;
}

export interface LotesVendidosResponseDTO {
  programas: ProgramaVendidoDTO[];
  totalGeneral: number;
  cantidadLotes: number;
}

@Injectable({
  providedIn: 'root'
})
export class ContratoService {

  private readonly apiUrl = `${environment.apiUrl}/api/contratos`;

  constructor(private http: HttpClient) { }

  listarContrato(): Observable<ContratoResponseDTO[]> {
    return this.http.get<ContratoResponseDTO[]>(`${this.apiUrl}/listar`);
  }

  listarContratosResumen(): Observable<ContratoListItemDTO[]> {
    return this.http.get<ContratoListItemDTO[]>(`${this.apiUrl}/listar-resumen`);
  }

  obtenerContratoPorId(id: number): Observable<ContratoResponseDTO> {
    return this.http.get<ContratoResponseDTO>(`${this.apiUrl}/${id}`);
  }

  buscarPorProgramaManzanaLote(idPrograma: number, manzana: string, numeroLote: string): Observable<ContratoResponseDTO> {
    const params = new HttpParams()
      .set('idPrograma', idPrograma.toString())
      .set('manzana', manzana)
      .set('numeroLote', numeroLote);
    return this.http.get<ContratoResponseDTO>(`${this.apiUrl}/buscar-por-lote`, { params });
  }

  buscarPorNombreCliente(termino: string): Observable<ContratoResponseDTO[]> {
    return this.http.get<ContratoResponseDTO[]>(`${this.apiUrl}/buscar-por-cliente`, {
      params: new HttpParams().set('termino', termino)
    });
  }

  buscarPorNombreClienteResumen(termino: string): Observable<ContratoListItemDTO[]> {
    return this.http.get<ContratoListItemDTO[]>(`${this.apiUrl}/buscar-por-cliente-resumen`, {
      params: new HttpParams().set('termino', termino)
    });
  }

  listarLotesVendidos(idVendedor?: number): Observable<LotesVendidosResponseDTO> {
    const params = idVendedor ? new HttpParams().set('idVendedor', idVendedor.toString()) : undefined;
    return this.http.get<LotesVendidosResponseDTO>(`${this.apiUrl}/lotes-vendidos`, { params });
  }

  guardarContrato(request: ContratoRequestDTO): Observable<ContratoResponseDTO> {
    return this.http.post<ContratoResponseDTO>(`${this.apiUrl}/agregar`, request);
  }

  actualizarContrato(id: number, request: ContratoRequestDTO): Observable<ContratoResponseDTO> {
    return this.http.put<ContratoResponseDTO>(`${this.apiUrl}/actualizar/${id}`, request);
  }

  eliminarContrato(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/eliminar/${id}`);
  }

  imprimirContratoPdf(id: number): Observable<Blob> {
    const timestamp = new Date().getTime();
    return this.http.get(`${this.apiUrl}/${id}/imprimir?t=${timestamp}`, {
      responseType: 'blob'
    });
  }

  descargarComprobanteInicial(idContrato: number): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/${idContrato}/pago-inicial/comprobante-pdf`, { responseType: 'blob' });
  }

  cambiarEstado(id: number, estado: string): Observable<ContratoResponseDTO> {
    const params = new HttpParams().set('estado', estado);
    return this.http.patch<ContratoResponseDTO>(`${this.apiUrl}/${id}/estado`, null, { params });
  }

  registrarRenuncia(id: number): Observable<ContratoResponseDTO> {
    return this.http.patch<ContratoResponseDTO>(`${this.apiUrl}/${id}/renuncia`, null);
  }

  registrarTransferencia(id: number): Observable<TransferenciaResponseDTO> {
    return this.http.patch<TransferenciaResponseDTO>(`${this.apiUrl}/${id}/transferencia`, null);
  }

  consultarImpactoEdicion(id: number): Observable<ImpactoEdicionDTO> {
    return this.http.get<ImpactoEdicionDTO>(`${this.apiUrl}/${id}/impacto-edicion`);
  }

 
  subirVoucherInicial(idContrato: number, voucher: File): Observable<ContratoResponseDTO> {
    const formData = new FormData();
    formData.append('voucher', voucher);
    return this.http.post<ContratoResponseDTO>(
      `${this.apiUrl}/${idContrato}/voucher-inicial`,
      formData
    );
  }

  anularPagoInicial(idContrato: number, motivo: string): Observable<import('../dto/pagoinicialresponse.dto').PagoInicialResponseDTO> {
    return this.http.patch<import('../dto/pagoinicialresponse.dto').PagoInicialResponseDTO>(
      `${this.apiUrl}/${idContrato}/pago-inicial/anular`,
      { motivo }
    );
  }

  // ── Lista de Contratos por programa y estado ────────────────────────────

  listaContratos(idPrograma: number | null, estados: string[]): Observable<any[]> {
    let params: any = {};
    if (idPrograma != null) params.idPrograma = idPrograma;
    if (estados && estados.length > 0) params.estados = estados;
    return this.http.get<any[]>(`${this.apiUrl}/lista-programa`, { params });
  }

  descargarListaExcel(idPrograma: number | null, estados: string[]): Observable<Blob> {
    let params: any = {};
    if (idPrograma != null) params.idPrograma = idPrograma;
    if (estados && estados.length > 0) params.estados = estados;
    return this.http.get(`${this.apiUrl}/lista-programa/excel`, { params, responseType: 'blob' });
  }

  descargarListaWord(idPrograma: number | null, estados: string[]): Observable<Blob> {
    let params: any = {};
    if (idPrograma != null) params.idPrograma = idPrograma;
    if (estados && estados.length > 0) params.estados = estados;
    return this.http.get(`${this.apiUrl}/lista-programa/word`, { params, responseType: 'blob' });
  }

  descargarListaPdf(idPrograma: number | null, estados: string[]): Observable<Blob> {
    let params: any = {};
    if (idPrograma != null) params.idPrograma = idPrograma;
    if (estados && estados.length > 0) params.estados = estados;
    return this.http.get(`${this.apiUrl}/lista-programa/pdf`, { params, responseType: 'blob' });
  }
}