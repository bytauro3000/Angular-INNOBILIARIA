import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import {
  ComisionVendedorDTO,
  PagoComisionMensualDTO,
  PagoComisionRequest,
  PagoComisionResponse,
  PagoComisionResultadoDTO,
  RegistrarAdelantoRequest,
  RegistrarPagosMensualesRequest
} from '../dto/comision-vendedor.dto';

@Injectable({ providedIn: 'root' })
export class ComisionVendedorService {

  private readonly apiUrl = `${environment.apiUrl}/api/comisiones`;

  constructor(private http: HttpClient) {}

  listarComisiones(): Observable<ComisionVendedorDTO[]> {
    return this.http.get<ComisionVendedorDTO[]>(this.apiUrl);
  }

  pagosMensualesHabilitados(idComision: number): Observable<PagoComisionMensualDTO[]> {
    return this.http.get<PagoComisionMensualDTO[]>(`${this.apiUrl}/${idComision}/pagos-habilitados`);
  }

  registrarAdelanto(request: RegistrarAdelantoRequest): Observable<PagoComisionResultadoDTO> {
    return this.http.post<PagoComisionResultadoDTO>(`${this.apiUrl}/adelantos`, request);
  }

  /** Registra un pago de comisión (adelanto o mensual multi-lote) con vouchers. */
  registrarPagoComision(request: PagoComisionRequest, vouchers?: File[]): Observable<PagoComisionResponse> {
    const formData = new FormData();
    formData.append('pago', new Blob([JSON.stringify(request)], { type: 'application/json' }));
    if (vouchers?.length) vouchers.forEach(v => formData.append('vouchers', v));
    return this.http.post<PagoComisionResponse>(`${this.apiUrl}/pagos/registrar`, formData);
  }

  actualizarMontoComision(idComision: number, monto: number): Observable<ComisionVendedorDTO> {
    return this.http.put<ComisionVendedorDTO>(`${this.apiUrl}/monto`, { idComision, monto });
  }

  registrarPagosMensuales(request: RegistrarPagosMensualesRequest): Observable<PagoComisionResultadoDTO> {
    return this.http.post<PagoComisionResultadoDTO>(`${this.apiUrl}/pagos`, request);
  }

  /** Anula manualmente una comisión por su ID. */
  anularComision(idComision: number): Observable<ComisionVendedorDTO> {
    return this.http.patch<ComisionVendedorDTO>(`${this.apiUrl}/${idComision}/anular`, {});
  }

  descargarEgresoPdf(numeroEgreso: string): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/egresos/${numeroEgreso}/pdf`, { responseType: 'blob' });
  }

  previewSiguienteEgreso(): Observable<string> {
    return this.http.get(`${this.apiUrl}/egresos/preview-siguiente`, { responseType: 'text' });
  }

  descargarReporteComisionPdf(idVendedor: number, soloPendientes: boolean = false): Observable<Blob> {
    const params = soloPendientes ? '?soloPendientes=true' : '';
    return this.http.get(`${this.apiUrl}/reporte/${idVendedor}/pdf${params}`, { responseType: 'blob' });
  }
}