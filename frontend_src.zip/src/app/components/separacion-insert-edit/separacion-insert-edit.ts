import { Component, OnInit, ViewChild, ElementRef, HostListener, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faPlus } from '@fortawesome/free-solid-svg-icons';
import { Router, RouterModule } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';

import { Separacion } from '../../models/separacion.model';
import { Cliente } from '../../models/cliente.model';
import { Lote } from '../../models/lote.model';
import { Programa } from '../../models/programa.model';
import { Vendedor } from '../../models/vendedor.model';
import { EstadoSeparacion } from '../../enums/estadoseparacion.enum';
import { TipoPropietario } from '../../enums/tipopropietario.enum';

import { ClienteService } from '../../services/cliente.service';
import { VendedorService } from '../../services/vendedor.service';
import { LoteService } from '../../services/lote.service';
import { ProgramaService } from '../../services/programa.service';
import { SeparacionService } from '../../services/separacion.service';

// Importa tus componentes de inserción rápida
import { ClienteInsertarComponent } from '../cliente-insertar/cliente-insertar.component';
import { VendedorInsertar } from '../vendedor-insertar/vendedor-insertar';
import { ProgramaInsertEdit } from '../programa-insertar-editar/programa-inset-edit';

// Calendario Material
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, MAT_DATE_LOCALE, DateAdapter } from '@angular/material/core';
import { MatInputModule } from '@angular/material/input';
import { obtenerFechaPeru } from '../../utils/fecha-peru';

@Component({
  selector: 'app-separacion-insert-edit',
  standalone: true,
  providers: [
    { provide: MAT_DATE_LOCALE, useValue: 'es-ES' } // Localización inicial
  ],
  imports: [
    CommonModule, FormsModule, ReactiveFormsModule, FontAwesomeModule, RouterModule,
    ClienteInsertarComponent, VendedorInsertar, ProgramaInsertEdit, 
    MatDatepickerModule, MatNativeDateModule, MatInputModule,
  ],
  templateUrl: './separacion-insert-edit.html',
  styleUrl: './separacion-insert-edit.scss'
})
export class SeparacionInsertEdit implements OnInit {
  @Output() operacionExitosa = new EventEmitter<void>();

  @ViewChild('clienteModal') clienteModal!: ClienteInsertarComponent;
  @ViewChild('vendedorModal') vendedorModal!: VendedorInsertar;
  @ViewChild('programaModal') programaModal!: ProgramaInsertEdit;

  @ViewChild('vendedorContainer') vendedorContainer!: ElementRef;
  @ViewChild('programaContainer') programaContainer!: ElementRef;
  @ViewChild('clienteContainer') clienteContainer!: ElementRef;
  @ViewChild('loteContainer') loteContainer!: ElementRef;

  isVisible = true;
  isEditMode = false;
  faPlus = faPlus;

  clientes: Cliente[] = [];
  vendedores: Vendedor[] = [];
  programas: Programa[] = [];
  lotes: Lote[] = [];

  filtroCliente = ''; mostrarClientes = false; clientesFiltrados: Cliente[] = [];
  filtroVendedor = ''; mostrarVendedores = false; vendedoresFiltrados: Vendedor[] = [];
  filtroPrograma = ''; mostrarProgramas = false; programasFiltrados: Programa[] = [];
  filtroLote = ''; mostrarLotes = false; lotesFiltrados: Lote[] = [];

  separacion: Separacion = this.getEmptySeparacion();
  programaSeleccionado: Programa | null = null;

  constructor(
    private clienteService: ClienteService,
    private vendedorService: VendedorService,
    private loteService: LoteService,
    private programaService: ProgramaService,
    private separacionService: SeparacionService,
    private toastr: ToastrService,
    public router: Router,
    private _adapter: DateAdapter<any> // Inyectar adaptador para forzar idioma
  ) {
    this._adapter.setLocale('es-ES'); // Configurar español al construir
  }

  ngOnInit(): void {
    this._adapter.setLocale('es-ES'); // Reforzar español
    this.cargarDatosMaestros();
  }

  @HostListener('document:click', ['$event'])
  onClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;
    if (this.vendedorContainer && !this.vendedorContainer.nativeElement.contains(target)) this.mostrarVendedores = false;
    if (this.programaContainer && !this.programaContainer.nativeElement.contains(target)) this.mostrarProgramas = false;
    if (this.clienteContainer && !this.clienteContainer.nativeElement.contains(target)) this.mostrarClientes = false;
    if (this.loteContainer && !this.loteContainer.nativeElement.contains(target)) this.mostrarLotes = false;
  }

  cargarDatosMaestros() {
    this.clientes = [];
    this.clientesFiltrados = [];
    this.vendedorService.listarVendedores().subscribe(v => { this.vendedores = v; this.vendedoresFiltrados = [...v]; });
    this.programaService.listarProgramas().subscribe(v => { this.programas = v; this.programasFiltrados = [...v]; });
    this.cargarClientesIniciales();
  }

  private cargarClientesIniciales(): void {
    this.clienteService.listarClientesPaginado(0, 200).subscribe(p => {
      this.clientes = p.content || [];
      if (this.mostrarClientes && this.filtroCliente.trim().length < 2) {
        this.clientesFiltrados = this.clientes.filter(c => !this.separacion.clientes.some(sc => sc.cliente.idCliente === c.idCliente));
      }
    });
  }

  abrirListaClientes() {
    if (this.clientes.length === 0) {
      this.cargarClientesIniciales();
    }
    if (this.filtroCliente.trim().length < 2) {
      this.mostrarClientes = true;
      this.clientesFiltrados = this.clientes.filter(c => !this.separacion.clientes.some(sc => sc.cliente.idCliente === c.idCliente));
      return;
    }
    this.filtrarClientes();
  }

  RecargarClientes() { this.cargarClientesIniciales(); }

  private getEmptySeparacion(): Separacion {
    return {
      monto: 0,
      fechaSeparacion: obtenerFechaPeru(),
      fechaLimite: '',
      estado: EstadoSeparacion.EN_PROCESO,
      clientes: [],
      lotes: []
    };
  }

  abrirModalCliente() { this.clienteModal.abrirModalCliente(); }
  abrirModalVendedor() { this.vendedorModal.abrirModal(); }
  abrirModalPrograma() { this.programaModal.abrirModal(); }

  filtrarClientes() {
    const f = this.filtroCliente.trim();
    if (f.length < 2) {
      this.mostrarClientes = true;
      this.clientesFiltrados = this.clientes.filter(c => !this.separacion.clientes.some(sc => sc.cliente.idCliente === c.idCliente));
      return;
    }
    this.clienteService.buscarClientesPorFiltro(f, /^\d+$/.test(f) ? 'documento' : 'nombres').subscribe(data => {
      this.clientesFiltrados = data.filter(c => !this.separacion.clientes.some(sc => sc.cliente.idCliente === c.idCliente));
      this.mostrarClientes = true;
    });
  }

  seleccionarCliente(c: Cliente) {
    this.separacion.clientes.push({ cliente: c, tipoPropietario: TipoPropietario.TITULAR, id: {} as any, separacion: {} as any });
    this.filtroCliente = '';
    this.mostrarClientes = false;
  }

  cambiarRolCliente(id: number, rol: TipoPropietario) {
    const sc = this.separacion.clientes.find(s => s.cliente.idCliente === id);
    if (sc) sc.tipoPropietario = rol;
  }

  get tipoPropietarioOptions(): TipoPropietario[] {
    return Object.values(TipoPropietario);
  }

  filtrarVendedores() {
    const f = this.filtroVendedor.toLowerCase();
    this.vendedoresFiltrados = this.vendedores.filter(v => `${v.nombre} ${v.apellidos}`.toLowerCase().includes(f) || v.dni.includes(f));
    this.mostrarVendedores = true;
  }

  seleccionarVendedor(v: Vendedor) {
    this.separacion.vendedor = v;
    this.filtroVendedor = `${v.nombre} ${v.apellidos}`;
    this.mostrarVendedores = false;
  }

  filtrarProgramas() {
    const f = this.filtroPrograma.toLowerCase();
    this.programasFiltrados = this.programas.filter(p => p.nombrePrograma.toLowerCase().includes(f));
    this.mostrarProgramas = true;
  }

  seleccionarPrograma(p: Programa) {
    this.programaSeleccionado = p;
    this.filtroPrograma = p.nombrePrograma;
    this.mostrarProgramas = false;
    this.lotes = [];
    this.lotesFiltrados = [];
    // Usa el endpoint por programa (trae idPrograma + estado) en vez de listar
    // todos y filtrar por l.programa (que no viene anidado en listarLotes).
    this.loteService.listarLotesEntidadPorPrograma(p.idPrograma!).subscribe(data => {
      this.lotes = data.filter(l => l.estado?.toString().toUpperCase() === 'DISPONIBLE');
      this.lotesFiltrados = [...this.lotes];
    });
  }

  filtrarLotes() {
    const f = this.filtroLote.toLowerCase();
    this.lotesFiltrados = this.lotes.filter(l => 
      `manzana ${l.manzana} lote ${l.numeroLote}`.toLowerCase().includes(f) &&
      !this.separacion.lotes.some(sl => sl.lote.idLote === l.idLote)
    );
    this.mostrarLotes = true;
  }

  seleccionarLote(l: Lote) {
    this.separacion.lotes.push({ lote: l, id: {} as any, separacion: {} as any });
    this.filtroLote = '';
    this.mostrarLotes = false;
  }

  quitarCliente(id: number) { this.separacion.clientes = this.separacion.clientes.filter(sc => sc.cliente.idCliente !== id); }
  quitarLote(id: number) { this.separacion.lotes = this.separacion.lotes.filter(sl => sl.lote.idLote !== id); }

  guardar() {
    if (this.separacion.clientes.length === 0 || this.separacion.lotes.length === 0 || !this.separacion.vendedor) {
      this.toastr.warning('Complete todos los campos requeridos', 'Atención');
      return;
    }
    const op = this.isEditMode ? this.separacionService.actualizarSeparacion(this.separacion.idSeparacion!, this.separacion) : this.separacionService.crearSeparacion(this.separacion);
    op.subscribe({
      next: () => {
        this.toastr.success('Separación guardada correctamente');
        this.router.navigate([this.basePath]);
      }
    });
  }

  /** Ruta de retorno según el menú desde el que se entró (vendedor o secretaría). */
  get basePath(): string {
    return this.router.url.includes('/vendedor-menu/')
      ? '/vendedor-menu/separaciones'
      : '/secretaria-menu/separaciones';
  }
}