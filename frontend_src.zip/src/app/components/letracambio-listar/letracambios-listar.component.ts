import { Component, OnInit, ViewChild, ElementRef, HostListener, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { LetrasCambioService } from '../../services/letracambio.service';
import { ContratoService } from '../../services/contrato.service';
import { LetraCambio } from '../../models/letra-cambio.model';
import { FormsModule } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';
import { jsPDF } from 'jspdf';
import { ReporteLetraCambioDTO } from '../../dto/reporteletracambio.dto';
import { ReporteCronogramaPagosClientesDTO } from '../../dto/reportecronogramapagocli.dto';
//Importa el módulo y la librería
import { FontAwesomeModule, FaIconLibrary } from '@fortawesome/angular-fontawesome';
//Importa los iconos específicos
import { faPrint, faCalendarAlt, faTrash, faPencilAlt } from '@fortawesome/free-solid-svg-icons';
@Component({
  selector: 'app-letracambio-listar',
  standalone: true,
  templateUrl: './letracambios-listar.html',
  styleUrls: ['./letracambios-listar.scss'],
  imports: [CommonModule, FormsModule, FontAwesomeModule],
})
export class LetracambioListarComponent implements OnInit, AfterViewInit {
  letras: LetraCambio[] = [];
  letrasFiltradas: LetraCambio[] = [];
  paginatedLetras: LetraCambio[] = [];

  terminoBusqueda: string = '';

  idContrato: number = 0;
  cargando: boolean = false;
  error: string | null = null;

  // Información del contrato para el título
  contratoLotes: { manzana: string; numeroLote: string; nombrePrograma: string }[] = [];

  // Paginación
  pageSize: number = 9;
  currentPage: number = 1;
  totalPages: number = 0;
  private readonly ROW_HEIGHT_PX = 50;
  private readonly PAGINATION_RESERVE_PX = 100;

  @ViewChild('tableBody') tableBody!: ElementRef<HTMLElement>;

  //Define propiedades para usar los iconos en el HTML
  faPrint = faPrint;
  faCalendarAlt = faCalendarAlt;
  faTrash = faTrash;
  faPencilAlt = faPencilAlt;

  // Edición en línea
  editingLetraId: number | null = null;
  campoEditando: 'importe' | 'importeLetras' | 'fechaVencimiento' | null = null;
  monedaContrato: string = 'USD'; // Se carga al obtener las letras
  valorTemporal: string | number = '';

  constructor(
    private letrasService: LetrasCambioService,
    private contratoService: ContratoService,
    private route: ActivatedRoute,
    private router: Router,
    private toastr: ToastrService,
    private cdr: ChangeDetectorRef,
    //Inyecta la librería de iconos en el constructor
    library: FaIconLibrary
  ) {
    //Registra los iconos instalados
    library.addIcons(faPrint, faCalendarAlt, faTrash, faPencilAlt);
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = params.get('idContrato');
      this.idContrato = id ? +id : 0;

      if (this.idContrato > 0) {
        this.cargarContratoInfo();
        this.cargarLetras();
      } else {
        this.error = 'ID de contrato inválido.';
      }
    });
  }

  ngAfterViewInit(): void {
    setTimeout(() => this.calcularPageSize(), 50);
  }

  @HostListener('window:resize')
  onResize(): void {
    this.calcularPageSize();
  }

  private calcularPageSize(): void {
    if (!this.tableBody?.nativeElement) return;
    const tbodyTop = this.tableBody.nativeElement.getBoundingClientRect().top;
    const available = window.innerHeight - tbodyTop - this.PAGINATION_RESERVE_PX;
    const nuevaPageSize = Math.max(3, Math.floor(available / this.ROW_HEIGHT_PX));
    if (nuevaPageSize !== this.pageSize) {
      this.pageSize = nuevaPageSize;
      this.currentPage = 1;
      this.aplicarPaginacion();
      this.cdr.detectChanges();
    }
  }

  cargarContratoInfo(): void {
    this.contratoService.obtenerContratoPorId(this.idContrato).subscribe({
      next: (contrato) => {
        if (contrato.lotes && contrato.lotes.length > 0) {
          this.contratoLotes = contrato.lotes.map(l => ({
            manzana: l.manzana,
            numeroLote: l.numeroLote,
            nombrePrograma: l.nombrePrograma
          }));
        }
      },
      error: () => {}
    });
  }

  get tituloLetras(): string {
    if (this.contratoLotes.length === 1) {
      const l = this.contratoLotes[0];
      return `Letras de Cambio - MZ. ${l.manzana} LT. ${l.numeroLote} - ${l.nombrePrograma}`;
    }
    if (this.contratoLotes.length > 1) {
      const progs = this.contratoLotes.map(l => l.nombrePrograma);
      const progUnico = progs.every(p => p === progs[0]) ? progs[0] : 'Varios programas';
      const mzLt = this.contratoLotes.map(l => `MZ. ${l.manzana} LT. ${l.numeroLote}`).join(' / ');
      return `Letras de Cambio - ${mzLt} - ${progUnico}`;
    }
    return `Letras de Cambio del Contrato #${this.idContrato}`;
  }

  cargarLetras(): void {
    this.cargando = true;
    this.error = null;

    this.letrasService.listarPorContrato(this.idContrato).subscribe({
      next: letras => {
        this.letras = letras;
        this.letrasFiltradas = [...letras];
        this.aplicarPaginacion();
        this.cargando = false;
        // Obtener moneda del contrato desde la primera letra
        if (letras.length > 0 && letras[0].monedaContrato) {
          this.monedaContrato = letras[0].monedaContrato;
        }
      },
      error: () => {
        this.error = 'Ocurrió un error al cargar las letras.';
        this.cargando = false;
      }
    });
  }

   // ══════════════════════════════════════════════════════════════════════════
  // IMPRIMIR LETRAS — VERSIÓN BACKEND (PDF generado en el servidor con iText)
  // Llama a GET /api/letras/pdf/{idContrato} y abre el resultado en nueva pestaña.
  // ══════════════════════════════════════════════════════════════════════════
  imprimirLetras(): void {
    this.cargando = true;
    this.letrasService.descargarPdfLetrasBackend(this.idContrato).subscribe({
      next: (blob: Blob) => {
        const lote = this.contratoLotes?.[0];
        const mz = lote?.manzana || '';
        const lt = lote?.numeroLote || '';
        const prog = lote?.nombrePrograma || '';
        const filename = `LETRA DE CAMBIO DE LA MZ. ${mz} LT. ${lt} - ${prog}.pdf`.replace(/\s+/g, ' ');
        this.toastr.info('Generando PDF…', 'Por favor espere');
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
        this.toastr.success('PDF generado correctamente.', 'Éxito');
        this.cargando = false;
      },
      error: () => {
        this.toastr.error('Ocurrió un error al generar el reporte PDF.', 'Error');
        this.cargando = false;
      }
    });
  }
/* VERSION FRONTEND (PDF generado en el cliente con jsPDF)
  //>>>>>>>>>>>>>>>>>>>>>>>>> INICIO DE IMPRIMIR LETRAS <<<<<<<<<<<<<<<<<<<<<<<//
  imprimirLetras(): void {
    this.cargando = true;

    // Obtener el reporte de letras del contrato
    this.letrasService.obtenerReportePorContrato(this.idContrato).subscribe({
      next: (reportes: ReporteLetraCambioDTO[]) => {
        // >>>>>>> BLOQUE DE CORRECCIÓN: ORDENAMIENTO ASCENDENTE <<<<<<<
        // Esto ordena las letras comparando la parte numérica de "numeroLetra" (ej. "1/110")
        reportes.sort((a, b) => {
          const numA = parseInt(a.numeroLetra.split('/')[0]);
          const numB = parseInt(b.numeroLetra.split('/')[0]);
          return numA - numB;
        });
        // >>>>>>>>>>>>>>>>>>>>>>>>> FIN BLOQUE <<<<<<<<<<<<<<<<<<<<<<<<<<<
        const doc = new jsPDF({
          orientation: 'landscape', // Orientación horizontal
          unit: 'mm',
          format: [216, 110],  // Tamaño de página 21 cm de ancho x 11 cm de alto
        });

        // Establecer la fuente para todo el documento (Times New Roman, negrita, tamaño 12)
        doc.setFont('times');
        doc.setFontSize(14);

        const espaciadoVertical = 10;  // Espacio entre las filas de datos

        // Iterar sobre los reportes para mostrarlos en el PDF
        reportes.forEach((reporte, index) => {
          // Si no es la primera letra, agregar una nueva página
          if (index > 0) {
            doc.addPage();  // Nueva página para cada letra
          }

          let y = 30;  // Reseteamos la posición Y para cada letra

          // Añadir la información de cada letra en la posición adecuada
          // Primera fila
          doc.setFontSize(10);
          doc.text(reporte.numeroLetra, 50, 22); // Número Letra
          doc.text(this.formatearFechaVista(reporte.fechaGiro), 99, 24); // Fecha de Giro formateada
          doc.text(reporte.distritoNombre, 129, 22); // Distrito Letra
          doc.text(this.formatearFechaVista(reporte.fechaVencimiento), 155, 24); // Fecha de Vencimiento formateada
          // Formatear el importe con separadores de miles y dos decimales
          const importeFormateado = reporte.importe.toLocaleString('en-US', { style: 'decimal', minimumFractionDigits: 2, maximumFractionDigits: 2 });
          doc.text(`${this.monedaContrato === 'PEN' ? 'S/ ' : '$ '} ${importeFormateado}`, 182, 22); // Importe con separadores de miles y decimales
          y += espaciadoVertical;

          // Segunda fila
          doc.text(reporte.importeLetras, 43, 38); // Importe en Letras
          y += espaciadoVertical;

          // Tercera fila (Nombre completo del cliente 1)
          if (reporte.cliente1Nombre) {
            const cliente1Info = reporte.cliente1Apellidos
              ? reporte.cliente1Nombre + ' ' + reporte.cliente1Apellidos
              : reporte.cliente1Nombre;

            doc.text(cliente1Info, 54, 49); // Cliente 1: Nombres, Apellidos (si existe)
            y += espaciadoVertical;
          }

          // Cuarta fila (Nombre2 + Apellidos2 + DNI del Cliente 2)
          if (reporte.cliente2Nombre) {
            const cliente2Info = reporte.cliente2Apellidos
              ? reporte.cliente2Nombre + ' ' + reporte.cliente2Apellidos
              : reporte.cliente2Nombre;

            doc.text(cliente2Info + ' ' + `DNI/RUC: ${reporte.cliente2NumDocumento}`, 44, 53); // Cliente 2: Nombres, Apellidos (si existe) y DNI
            y += espaciadoVertical;
          }

          // Sexta fila (Dirección del cliente 1)
          doc.text(reporte.cliente1Direccion, 52, 58); // Dirección Cliente 1
          y += espaciadoVertical;

          // Quinta fila (DNI del cliente 1)
          doc.text(reporte.cliente1NumDocumento, 50, 64); // DNI Cliente 1
          y += espaciadoVertical;


          // Séptima fila (Distrito del cliente 1)
          doc.text(`distrito: ${reporte.cliente1Distrito}`, 88, 62); // Distrito Cliente 1
          y += espaciadoVertical;

          // Espacio adicional entre registros
          y += espaciadoVertical;
        });

        // 1. Crear el objeto binario
        const blob = doc.output('blob');

        // 2. Crear la URL temporal
        const url = URL.createObjectURL(blob);

        // 3. Abrir en pestaña nueva
        const pdfWindow = window.open(url, '_blank');

        // 4. Liberar memoria (La línea recomendada)
        if (pdfWindow) {
          // Liberamos el objeto después de que el navegador haya tenido tiempo de cargarlo
          setTimeout(() => URL.revokeObjectURL(url), 100);
        }

        this.cargando = false;
      },
      error: () => {
        this.toastr.error('Ocurrió un error al generar el reporte PDF.', 'Error');
        this.cargando = false;
      }
    });
  }
*/
  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> INICIO <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<//

  // Nueva función para generar el PDF del cronograma de pagos
  imprimirCronogramaPagos(): void {
    this.cargando = true;

    this.letrasService.obtenerReporteCronogramaPagosPorContrato(this.idContrato).subscribe({
      next: (reporte: ReporteCronogramaPagosClientesDTO[]) => {
        if (!reporte || reporte.length === 0) {
          this.toastr.info('No hay datos para generar el cronograma de pagos.', 'Sin datos');
          this.cargando = false;
          return;
        }

        reporte.sort((a, b) => {
        const numA = parseInt(a.numeroLetra.split('/')[0]);
        const numB = parseInt(b.numeroLetra.split('/')[0]);
        return numA - numB;
      });

        const doc = new jsPDF({
          orientation: 'portrait',
          unit: 'mm',
          format: 'a4',
        });

        

        const margin = 15;
        const pageWidth = doc.internal.pageSize.getWidth();
        const pageHeight = doc.internal.pageSize.getHeight();
        const tableWidth = 124;
        const tableX = (pageWidth - tableWidth) / 2;
        const rowHeight = 7;

        let y = 10;
        let currentPage = 1;

        // Ancho de columnas
        const colWidths = { 'N°': 30, 'Vencimiento': 60, 'Importe': 40 };
        const colStarts = {
          'N°': tableX,
          'Vencimiento': tableX + colWidths['N°'],
          'Importe': tableX + colWidths['N°'] + colWidths['Vencimiento'],
        };

        // ENCABEZADO INICIAL (Página 1)
        this.addHeader(doc, reporte[0], currentPage, margin);

        // --- AJUSTE 1: Espacio reducido (de 70 a 60) ---
        y = 65;

        this.drawTableHeader(doc, y, margin, colWidths, colStarts, tableWidth);
        y += rowHeight;

        let totalImporte = 0;

        reporte.forEach((letra, index) => {
          // CONTROL DE SALTO DE PÁGINA
          if (y + rowHeight > pageHeight - 20) {
            doc.addPage();
            currentPage++;
            // --- AJUSTE 2: Margen superior en paginas nuevas y NO dibujar cabecera ---
            y = margin;
            doc.setFont('times', 'normal');
          }

          const numeroLetra = letra.numeroLetra.split('/')[0];
          doc.setFont('times', 'normal');
          doc.setFontSize(10);
          doc.setDrawColor(200, 200, 200);
          doc.rect(tableX, y, tableWidth, rowHeight);

          doc.text(numeroLetra, colStarts['N°'] + colWidths['N°'] / 2, y + 4.5, { align: 'center' });
          doc.text(this.formatearFechaVista(letra.fechaVencimiento), colStarts['Vencimiento'] + colWidths['Vencimiento'] / 2, y + 4.5, { align: 'center' });
          doc.text(`${this.monedaContrato === 'PEN' ? 'S/ ' : '$ '}${letra.importe.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, colStarts['Importe'] + colWidths['Importe'] / 2, y + 4.5, { align: 'center' });

          doc.line(colStarts['Vencimiento'], y, colStarts['Vencimiento'], y + rowHeight);
          doc.line(colStarts['Importe'], y, colStarts['Importe'], y + rowHeight);

          totalImporte += letra.importe;
          y += rowHeight;
        });

        // FILA DE TOTALES
        if (y + rowHeight > pageHeight - margin) {
          doc.addPage();
          y = margin;
        }
        doc.setFont('times', 'bold');
        doc.setFontSize(10);
        doc.rect(tableX, y, tableWidth, rowHeight);
        doc.text('SUMA DE IMPORTE:', colStarts['N°'] + (colWidths['N°'] + colWidths['Vencimiento']) / 2, y + 4.5, { align: 'center' });
        doc.text(`${this.monedaContrato === 'PEN' ? 'S/ ' : '$ '}${totalImporte.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, colStarts['Importe'] + colWidths['Importe'] / 2, y + 4.5, { align: 'center' });

        // 2. LÓGICA DE FIRMAS
        y += 28; // Espacio mínimo después de la tabla (reducido de 15 a 5)

        // Reducimos el bloque de seguridad de 20 a 12mm
        // Esto permite que la firma se dibuje más cerca del final
        if (y + 12 > pageHeight - 10) {
          doc.addPage();
          y = margin + 20;
        }

        const lineWidth = 60;
        doc.setFontSize(9);
        doc.setFont('times', 'normal');

        const maxWidth = 55;      // Ancho máximo del texto antes de saltar de línea
        const lineHeight = 4.5;   // Espaciado entre líneas de texto
        const anchoLinea = 65;    // Ancho fijo de la línea (Estilo iText - aprox 200pt)

        if (reporte[0].cliente2Nombre) {
          // --- DISEÑO PARA 2 CLIENTES ---
          const centerX1 = margin + 40;            // Centro del bloque izquierdo
          const centerX2 = pageWidth - margin - 40; // Centro del bloque derecho

          // --- CLIENTE 1 ---
          const nombre1 = `${reporte[0].cliente1Nombre} ${reporte[0].cliente1Apellidos ?? ''}`.toUpperCase();
          const nombreLines1 = doc.splitTextToSize(nombre1, maxWidth); // Envolver texto

          doc.line(centerX1 - (anchoLinea / 2), y, centerX1 + (anchoLinea / 2), y); // Línea estética

          nombreLines1.forEach((line: string, i: number) => {
            doc.text(line, centerX1, y + 5 + (i * lineHeight), { align: 'center' });
          });

          // El DNI se dibuja dinámicamente debajo de la última línea del nombre
          const dniY1 = y + 5 + (nombreLines1.length * lineHeight);
          doc.text(`DNI: ${reporte[0].cliente1NumDocumento}`, centerX1, dniY1, { align: 'center' });

          // --- CLIENTE 2 ---
          const nombre2 = `${reporte[0].cliente2Nombre} ${reporte[0].cliente2Apellidos ?? ''}`.toUpperCase();
          const nombreLines2 = doc.splitTextToSize(nombre2, maxWidth);

          doc.line(centerX2 - (anchoLinea / 2), y, centerX2 + (anchoLinea / 2), y);

          nombreLines2.forEach((line: string, i: number) => {
            doc.text(line, centerX2, y + 5 + (i * lineHeight), { align: 'center' });
          });

          const dniY2 = y + 5 + (nombreLines2.length * lineHeight);
          doc.text(`DNI: ${reporte[0].cliente2NumDocumento}`, centerX2, dniY2, { align: 'center' });

        } else {
          // --- DISEÑO PARA 1 SOLO CLIENTE (Centrado) ---
          const centerX = pageWidth / 2;
          const nombre = `${reporte[0].cliente1Nombre} ${reporte[0].cliente1Apellidos ?? ''}`.toUpperCase();
          const nombreLines = doc.splitTextToSize(nombre, maxWidth);

          doc.line(centerX - (anchoLinea / 2), y, centerX + (anchoLinea / 2), y);

          nombreLines.forEach((line: string, i: number) => {
            doc.text(line, centerX, y + 5 + (i * lineHeight), { align: 'center' });
          });

          const dniY = y + 5 + (nombreLines.length * lineHeight);
          doc.text(`DNI: ${reporte[0].cliente1NumDocumento}`, centerX, dniY, { align: 'center' });
        }

        // --- FIRMA DEL AVAL (si existe) ---
        if (reporte[0].aval1Nombre) {
          const maxLines = Math.max(
            (reporte[0].cliente2Nombre
              ? doc.splitTextToSize(`${reporte[0].cliente1Nombre} ${reporte[0].cliente1Apellidos ?? ''}`.toUpperCase(), maxWidth).length
              : doc.splitTextToSize(`${reporte[0].cliente1Nombre} ${reporte[0].cliente1Apellidos ?? ''}`.toUpperCase(), maxWidth).length),
            reporte[0].cliente2Nombre
              ? doc.splitTextToSize(`${reporte[0].cliente2Nombre} ${reporte[0].cliente2Apellidos ?? ''}`.toUpperCase(), maxWidth).length
              : 0
          );
          const firmaAvalY = y + 5 + (maxLines * lineHeight) + 10;
          const centerAval = pageWidth / 2;
          const nombreAval = `${reporte[0].aval1Nombre} ${reporte[0].aval1Apellidos ?? ''}`.toUpperCase();
          const nombreAvalLines = doc.splitTextToSize(nombreAval, maxWidth);

          doc.line(centerAval - (anchoLinea / 2), firmaAvalY, centerAval + (anchoLinea / 2), firmaAvalY);
          nombreAvalLines.forEach((line: string, i: number) => {
            doc.text(line, centerAval, firmaAvalY + 5 + (i * lineHeight), { align: 'center' });
          });
          const dniAvalY = firmaAvalY + 5 + (nombreAvalLines.length * lineHeight);
          doc.text(`DNI: ${reporte[0].aval1NumDocumento ?? ''}`, centerAval, dniAvalY, { align: 'center' });
          doc.text('LA AVAL', centerAval, dniAvalY + 5, { align: 'center' });
        }
        const pageCount = (doc.internal as any).getNumberOfPages();
        for (let i = 1; i <= pageCount; i++) {
          doc.setPage(i);
          doc.setFontSize(8);
          doc.setFont('times', 'normal');
          doc.text(`Página ${i} de ${pageCount}`, pageWidth - margin, pageHeight - 10, { align: 'right' });
        }

        this.toastr.info('Generando PDF…', 'Por favor espere');
        const lote = this.contratoLotes?.[0];
        const mz = lote?.manzana || '';
        const lt = lote?.numeroLote || '';
        const prog = lote?.nombrePrograma || '';
        const filename = `CRONOGRAMA DE PAGOS DE LA MZ. ${mz} LT. ${lt} - ${prog}.pdf`.replace(/\s+/g, ' ');
        doc.save(filename);
        this.toastr.success('PDF generado correctamente.', 'Éxito');
        this.cargando = false;
      },
      error: () => {
        this.toastr.error('Error al generar el cronograma.', 'Error');
        this.cargando = false;
      }
    });
  }

  // Dibuja el encabezado de la tabla
  private drawTableHeader(doc: jsPDF, y: number, margin: number, colWidths: any, colStarts: any, tableWidth: number): void {
    doc.setFontSize(10);
    doc.setFont('times', 'bold');
    doc.setFillColor(200, 200, 200);

    // Dibuja el rectángulo de fondo para toda la cabecera
    doc.rect(colStarts['N°'], y, tableWidth, 7, 'F');  // Usar el ancho de la tabla centrada

    // Dibuja los textos de la cabecera centrados en sus respectivas columnas
    doc.text('N° Letra', colStarts['N°'] + colWidths['N°'] / 2, y + 4.5, { align: 'center' });
    doc.text('Vencimiento', colStarts['Vencimiento'] + colWidths['Vencimiento'] / 2, y + 4.5, { align: 'center' });
    doc.text('Importe', colStarts['Importe'] + colWidths['Importe'] / 2, y + 4.5, { align: 'center' });

    // Dibujar líneas verticales (separadores de las cabeceras) con el mismo color que las líneas horizontales
    doc.setDrawColor(200, 200, 200); // Color igual a las líneas horizontales
    doc.line(colStarts['N°'] + colWidths['N°'], y, colStarts['N°'] + colWidths['N°'], y + 7); // Línea vertical después de la columna "N°"
    doc.line(colStarts['Vencimiento'] + colWidths['Vencimiento'], y, colStarts['Vencimiento'] + colWidths['Vencimiento'], y + 7); // Línea vertical después de la columna "Vencimiento"
  }

  /** Abrevia el nombre del vendedor: quita "CONSTRUCTORA" si está presente
   *  (ej: "INMOBILIARIA CONSTRUCTORA IVAN" → "INMOBILIARIA IVAN"). */
  private formatearVendedor(nombre: string, apellidos: string): string {
    const completo = `${nombre ?? ''} ${apellidos ?? ''}`.trim();
    return completo
      .replace(/\s+CONSTRUCTORA\s+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // La función 'addHeader' debe ir aquí, dentro de la clase, como un método privado.
  private addHeader(doc: jsPDF, data: ReporteCronogramaPagosClientesDTO, page: number, margin: number): void {
    const pageWidth = doc.internal.pageSize.getWidth();
    let y = 15;

    // Título y fecha
    doc.setFontSize(14);
    doc.setFont('times', 'bold');
    doc.text('CRONOGRAMA DE PAGOS', pageWidth / 2, y, { align: 'center' });
    doc.setFontSize(10);
    doc.setFont('times', 'normal');
    doc.text(`Fecha de Emisión: ${new Date().toLocaleDateString()}`, pageWidth - margin, y, { align: 'right' });

    y += 10;
    doc.setFontSize(10);
    doc.text(`Proyecto: ${data.programaNombre}`, margin, y);
    doc.text(`Vendedor: ${this.formatearVendedor(data.vendedorNombre, data.vendedorApellidos)}`, 145, y);

    // Información del cliente
    y += 5;
    doc.setFont('times', 'bold');
    doc.text('Datos del Cliente', margin, y);
    doc.text(`Celular: ${data.cliente1Celular}`, 145, y);
    doc.setFont('times', 'normal');

    // Fila dinámica: cliente1 → cliente2 (si existe) → aval (si existe),
    // contiguas, sin dejar espacio en blanco entre ellas.
    let filaY = y + 5;

    // ── Cliente 1 (siempre, es el titular) ──
    doc.text(`Nombre 1: ${data.cliente1Nombre} ${data.cliente1Apellidos ?? ''}`, margin, filaY);
    doc.text(`DNI: ${data.cliente1NumDocumento}`, 145, filaY);
    filaY += 5;

    // ── Cliente 2 (solo si existe OTRO titular) ──
    if (data.cliente2Nombre) {
      doc.text(`Nombre 2: ${data.cliente2Nombre} ${data.cliente2Apellidos ?? ''}`, margin, filaY);
      doc.text(`DNI: ${data.cliente2NumDocumento ?? ''}`, 145, filaY);
      filaY += 5;
    }

    // ── Aval (solo si existe) — va en la fila siguiente al último cliente ──
    if (data.aval1Nombre) {
      doc.text(`Aval: ${data.aval1Nombre} ${data.aval1Apellidos ?? ''}`, margin, filaY);
      doc.text(`DNI: ${data.aval1NumDocumento ?? ''}`, 145, filaY);
      filaY += 5;
    }

    // ── Dirección y distrito del cliente 1 (debajo de las filas de personas) ──
    doc.text(`Dirección: ${data.cliente1Direccion}`, margin, filaY);
    doc.text(`Distrito: ${data.cliente1Distrito}`, 145, filaY);
    filaY += 5;

    // Información del lote (Teléfono va en la misma fila que "Datos del Lote")
    y = filaY;
    doc.setFont('times', 'bold');
    doc.text('Datos del Lote', margin, y);
    doc.text(`Teléfono: ${data.cliente1Telefono}`, 145, y);
    doc.setFont('times', 'normal');

    doc.text(`Lote 1: Manzana ${data.lote1Manzana ?? ''}, Lote ${data.lote1NumeroLote ?? ''} - Área: ${data.lote1Area ?? ''} m²`, margin, y + 5);
    // Lote 2: Si hay datos, mostrar Lote 2, si no mostrar vacío
    if (data.lote2Manzana && data.lote2NumeroLote && data.lote2Area) {
      doc.text(
        `Lote 2: Manzana ${data.lote2Manzana}, Lote ${data.lote2NumeroLote} - Área: ${data.lote2Area} m²`,
        margin,
        y + 10
      );
    } else {
      // Si Lote 2 no tiene datos, mostrar solo "Lote 2:" vacío
      doc.text('Lote 2: ', margin, y + 10);
    }
    doc.text(`N° de Letras:${data.cantidadLetras}`, 94, y + 5);
    doc.setFont('times', 'bold');
    doc.text(`Inicial: ${this.monedaContrato === 'PEN' ? 'S/' : '$'} ${data.inicial?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 145, y + 5);

    doc.text(`Monto Total: ${this.monedaContrato === 'PEN' ? 'S/' : '$'} ${data.montoTotal?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 94, y + 10);
    doc.text(`Saldo: ${this.monedaContrato === 'PEN' ? 'S/' : '$'} ${data.saldo?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 145, y + 10);


    // **Eliminado el if(page === 1) para que no se imprima aquí, ya que se hará en un bucle al final**
  }


  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> FIN <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<//
  filtrarLetras(): void {
    const termino = this.terminoBusqueda.trim().toLowerCase();

    if (!termino) {
      this.letrasFiltradas = [...this.letras];
    } else {
      this.letrasFiltradas = this.letras.filter(letra => {
        const parteAntesDeSlash = letra.numeroLetra?.split('/')[0].toLowerCase();
        return parteAntesDeSlash === termino;
      });
    }

    this.currentPage = 1;
    this.aplicarPaginacion();
  }

  aplicarPaginacion(): void {
    this.totalPages = Math.ceil(this.letrasFiltradas.length / this.pageSize);
    const start = (this.currentPage - 1) * this.pageSize;
    const end = start + this.pageSize;
    this.paginatedLetras = this.letrasFiltradas.slice(start, end);
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.aplicarPaginacion();
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.aplicarPaginacion();
    }
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.aplicarPaginacion();
    }
  }

 getPagesArray(): (number | string)[] {
  const total = this.totalPages;
  const current = this.currentPage;
  const pages: (number | string)[] = [];

  // Si hay 7 páginas o menos, se muestran todas normalmente
  if (total <= 7) {
    for (let i = 1; i <= total; i++) pages.push(i);
  } else {
    // Siempre mostramos la página 1
    pages.push(1);

    // Lógica de elipsis inicial
    if (current > 3) {
      pages.push('...');
    }

    // Rango central dinámico (alrededor de la actual)
    let start = Math.max(2, current - 1);
    let end = Math.min(total - 1, current + 1);

    // Ajustes para mantener siempre 3 números en el centro si es posible
    if (current <= 3) end = 4;
    if (current >= total - 2) start = total - 3;

    for (let i = start; i <= end; i++) {
      pages.push(i);
    }

    // Lógica de elipsis final
    if (current < total - 2) {
      pages.push('...');
    }

    // Siempre mostramos la última página
    pages.push(total);
  }
  return pages;
}

  eliminarLetras(): void {
    Swal.fire({
      title: '¿Estás seguro?',
      text: '¡No podrás revertir esto!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar'
    }).then(result => {
      if (result.isConfirmed) {
        this.cargando = true;
        this.error = null;

        this.letrasService.eliminarPorContrato(this.idContrato).subscribe({
          next: () => {
            this.toastr.success('Letras eliminadas correctamente.', '¡Éxito!');
            this.letras = [];
            this.letrasFiltradas = [];
            this.paginatedLetras = [];
            this.cargando = false;
            // Redirigir al formulario de generar letras ahora que no hay letras
            this.router.navigate(['/secretaria-menu/letras/insertar', this.idContrato]);
          },
          error: () => {
            this.toastr.error('Error al eliminar las letras.', 'Error');
            this.cargando = false;
          }
        });
      }
    });
  }

  // ------------------------------------------------
  // Convierte número a letras con moneda en dólares americanos
  // ------------------------------------------------
  convertirNumeroALetras(valor: number): string {
    if (isNaN(valor) || valor === 0) return 'CERO CON 00/100 DÓLARES AMERICANOS';

    // Separar la parte entera y decimal
    const partes = valor.toFixed(2).split('.');
    const entero = parseInt(partes[0], 10);
    const decimal = partes[1]; // ya es string con dos dígitos

    let letras = this.numeroALetras(entero).toUpperCase();

    // Siempre agregamos la parte decimal con el formato CON XX/100
    letras += ` CON ${decimal}/100 DÓLARES AMERICANOS`;

    return letras;
  }

  // ------------------------------------------------
  // Función privada para convertir número entero a letras
  // ------------------------------------------------
  private numeroALetras(num: number): string {
    const unidades = ["", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve"];
    const especiales = ["diez", "once", "doce", "trece", "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve"];
    const decenas = ["", "", "veinte", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa"];
    const centenas = ["", "ciento", "doscientos", "trescientos", "cuatrocientos", "quinientos", "seiscientos", "setecientos", "ochocientos", "novecientos"];

    if (num === 0) return "cero";
    if (num === 100) return "cien";

    let letras = "";

    if (num >= 1000000) {
      const millones = Math.floor(num / 1000000);
      letras += (millones === 1 ? "un millón" : this.numeroALetras(millones) + " millones");
      num %= 1000000;
      if (num > 0) letras += " ";
    }

    if (num >= 1000) {
      const miles = Math.floor(num / 1000);
      if (miles === 1) {
        letras += "mil";
      } else {
        letras += this.numeroALetras(miles) + " mil";
      }
      num %= 1000;
      if (num > 0) letras += " ";
    }

    if (num >= 100) {
      const c = Math.floor(num / 100);
      letras += centenas[c];
      num %= 100;
      if (num > 0) letras += " ";
    }

    if (num >= 10 && num <= 19) {
      letras += especiales[num - 10];
    } else if (num < 10) {
      letras += unidades[num];
    } else {
      const d = Math.floor(num / 10);
      const u = num % 10;
      if (d === 2 && u > 0) {
        letras += "veinti" + unidades[u];
      } else {
        letras += decenas[d];
        if (u > 0) letras += " y " + unidades[u];
      }
    }

    return letras.trim();
  }


  // ------------------------------
  // Métodos para edición en línea
  // ------------------------------

  iniciarEdicion(letra: LetraCambio, campo: 'importe' | 'importeLetras' | 'fechaVencimiento'): void {
    this.editingLetraId = letra.idLetra;
    this.campoEditando = campo;
    if (campo === 'fechaVencimiento') {
      // El input type="date" necesita el formato YYYY-MM-DD
      const fv = letra.fechaVencimiento;
      if (fv) {
        const str = typeof fv === 'string' ? fv : (fv as Date).toISOString().split('T')[0];
        // Normalizar: si viene como DD/MM/YYYY convertir a YYYY-MM-DD
        this.valorTemporal = str.includes('/') 
          ? str.split('/').reverse().join('-') 
          : str.split('T')[0];
      } else {
        this.valorTemporal = '';
      }
    } else {
      this.valorTemporal = letra[campo] ?? '';
    }
  }

  onFechaVencimientoInput(valor: string): void {
    this.valorTemporal = valor; // formato YYYY-MM-DD del input date
  }

  onImporteInput(letra: LetraCambio, valor: string): void {
    const numero = Number(valor);
    if (!isNaN(numero)) {
      this.valorTemporal = numero;
      letra.importe = numero;
      letra.importeLetras = this.convertirNumeroALetras(numero);
    } else {
      this.valorTemporal = valor;
      letra.importeLetras = '';
    }
  }

  guardarEdicion(letra: LetraCambio): void {
    if (!this.campoEditando || this.editingLetraId === null) return;

    if (this.campoEditando === 'importe') {
      letra.importe = Number(this.valorTemporal);
      letra.importeLetras = this.convertirNumeroALetras(letra.importe);
    }

    if (this.campoEditando === 'fechaVencimiento') {
      if (!this.valorTemporal) { this.cancelarEdicion(); return; }
      letra.fechaVencimiento = this.valorTemporal as string;
    }

    this.letrasService.actualizarLetra(letra.idLetra, letra).subscribe({
      next: () => {
        this.toastr.success('Letra actualizada correctamente.', 'Éxito');
        // Recargar la lista para reflejar el reordenamiento automático del
        // cronograma (las letras siguientes cambian de fecha/estado en el backend).
        this.cargarLetras();
      },
      error: () => {
        this.toastr.error('Error al actualizar la letra.', 'Error');
      },
      complete: () => {
        this.cancelarEdicion();
      }
    });
  }

  cancelarEdicion(): void {
    this.editingLetraId = null;
    this.campoEditando = null;
    this.valorTemporal = '';
  }

  // Función auxiliar para formatear fechas de YYYY-MM-DD a DD/MM/YYYY
  private formatearFechaVista(fechaStr: string | Date): string {
    if (!fechaStr) return '';
    // Convertimos a string por si viene como objeto Date
    const fecha = typeof fechaStr === 'string' ? fechaStr : fechaStr.toISOString().split('T')[0];
    const [anio, mes, dia] = fecha.split('-');
    return `${dia}/${mes}/${anio}`;
  }
}