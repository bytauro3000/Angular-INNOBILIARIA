import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ContratoService } from '../../services/contrato.service';
import { ProgramaService } from '../../services/programa.service';
import { VendedorService } from '../../services/vendedor.service';
import { SeparacionService } from '../../services/separacion.service';
import { ClienteService } from '../../services/cliente.service';
import { LoteService } from '../../services/lote.service';
import { Cliente } from '../../models/cliente.model';
import { Lote } from '../../models/lote.model';
import { Programa } from '../../models/programa.model';
import { Vendedor } from '../../models/vendedor.model';
import { SeparacionDTO } from '../../dto/separacion.dto';
import { ContratoRequestDTO, ContratoClienteRequestDTO } from '../../dto/contratorequest.dto';
import { TipoPropietario } from '../../enums/tipopropietario.enum';
import { PagoInicialRequestDTO } from '../../dto/pagoinicialrequest.dto';
import { ActivatedRoute, RouterModule, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { faPlus } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { VendedorInsertar } from '../vendedor-insertar/vendedor-insertar';
import { ClienteInsertarComponent } from '../cliente-insertar/cliente-insertar.component';
import { ProgramaInsertEdit } from '../programa-insertar-editar/programa-inset-edit';
import { LotesInsertarEditar } from '../lotes-insertar-editar/lotes-insertar-editar';
import { CurrencyFormatterDirective } from '../../directives/currency-formatter';
import { Moneda } from '../../dto/moneda.enum';
import { TipoCambioService } from '../../services/tipo-cambio.service';
import { TipoComprobante } from '../../enums/tipocomprobante';
import { MedioPago } from '../../enums/mediopago.enum';
import { PagoLetraService } from '../../services/pagoletra.service';
import { VoucherPreviewComponent } from '../voucher-preview/voucher-preview.componente';
import { VoucherOcrData } from '../../services/ocr-voucher.service';
import { obtenerFechaPeru } from '../../utils/fecha-peru';
import { loteCoincide } from '../../utils/lote-filtro';
import { TokenService } from '../../auth/token.service';

/** Cliente agregado al contrato con su rol (TITULAR, AVAL, etc.). */
export interface ClienteSeleccionado extends Cliente {
  tipoPropietario: TipoPropietario;
}

@Component({
  selector: 'app-contrato-insertar',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule, RouterModule, FormsModule,
    FontAwesomeModule, VendedorInsertar, ClienteInsertarComponent,
    ProgramaInsertEdit, LotesInsertarEditar, CurrencyFormatterDirective,
    VoucherPreviewComponent
  ],
  templateUrl: './contrato-insertar.html',
  styleUrls: ['./contrato-insertar.scss'],
})
export class ContratoInsertarComponent implements OnInit {
  @ViewChild('vendedorModalContrato') vendedorModalContrato!: VendedorInsertar;
  @ViewChild('registroModal') registroModal!: ClienteInsertarComponent;
  @ViewChild('registroModalPrograma') registroModalPrograma!: ProgramaInsertEdit;
  @ViewChild('loteModalContrato') loteModalContrato!: LotesInsertarEditar;

  @ViewChild('vendedorBusquedaContainer') vendedorBusquedaContainer!: ElementRef;
  @ViewChild('programaBusquedaContainer') programaBusquedaContainer!: ElementRef;
  @ViewChild('clienteBusquedaContainer') clienteBusquedaContainer!: ElementRef;
  @ViewChild('loteBusquedaContainer') loteBusquedaContainer!: ElementRef;

  contratoForm!: FormGroup;
  programas: Programa[] = [];
  lotes: Lote[] = [];
  vendedores: Vendedor[] = [];
  clientes: Cliente[] = [];
  separaciones: SeparacionDTO[] = [];
  clientesSeleccionados: ClienteSeleccionado[] = [];
  lotesSeleccionados: Lote[] = [];

  tipoPropietarioOptions = Object.values(TipoPropietario);

  modalidadContratoValues = ['DIRECTO', 'SEPARACION'];
  tipoContratoValues = ['CONTADO', 'FINANCIADO'];
  tipoComprobanteOptions = Object.values(TipoComprobante).filter(t => t === 'RECIBO' || t === 'BOLETA');
  medioPagoOptions = Object.values(MedioPago);

  terminoBusquedaSeparacion: string = '';
  showSeparacionList: boolean = false;
  faPlus = faPlus;
  isGuardando: boolean = false;
  mostrarModalConfirmacion: boolean = false;
  saldoDisplay: string = '$ 0.00';
  monedaSeleccionada: Moneda = 'USD';
  tipoCambioEmpresa: number = 0;
  tipoCambioCompra: number = 0;

  vendedoresFiltrados: Vendedor[] = [];
  filtroVendedor: string = '';
  mostrarVendedores: boolean = false;

  programasFiltrados: Programa[] = [];
  filtroPrograma: string = '';
  mostrarProgramas: boolean = false;

  clientesFiltrados: Cliente[] = [];
  filtroCliente: string = '';
  mostrarClientes: boolean = false;

  lotesFiltrados: Lote[] = [];
  filtroLote: string = '';
  mostrarLotes: boolean = false;

  // ── Modal Pago Inicial ────────────────────────────────────────────────
  mostrarModalPagoInicial: boolean = false;
  pagoInicialRequest: PagoInicialRequestDTO = this.resetPagoInicial();

  // Comprobante dentro del modal
  cargandoPreviewInicial: boolean = false;
  numeroComprobanteInicialPreview: string = '';
  modoManualComprobanteInicial: boolean = false;
  numeroComprobanteInicialManual: string = '';

  // Voucher dentro del modal
  voucherInicialFiles: File[] = [];

  // OCR por voucher del pago inicial: se acumulan los N° de operación (coma) y
  // se conserva la fecha más alta detectada entre todos los vouchers.
  private ocrOperationNumbers: Map<string, string> = new Map();
  private ocrVoucherFechas: Map<string, string> = new Map();
  private ocrVoucherHoras: Map<string, string> = new Map();
  private ocrFechaOperacion: string | null = null;
  private ocrHoraOperacion: string | null = null;

  // Estado del guardado (para el flujo de 2 pasos: guardar contrato → subir voucher)
  idContratoGuardado: number | null = null;

  esTransferencia = false;
  idContratoOrigen: number | null = null;

  get esDirecto(): boolean { return this.contratoForm?.get('modalidadContrato')?.value === 'DIRECTO'; }
  get esFinanciado(): boolean { return this.contratoForm?.get('tipoContrato')?.value !== 'CONTADO'; }
  get montoTotalNum(): number { return Number(this.contratoForm?.get('montoTotal')?.value) || 0; }
  get inicialNum(): number { return Number(this.contratoForm?.get('inicial')?.value) || 0; }
  get saldoNum(): number { return Number(this.contratoForm?.get('saldo')?.value) || 0; }
  get cantidadLetrasNum(): number { return Number(this.contratoForm?.get('cantidadLetras')?.value) || 0; }

  /** Mostrar botón "Pago de Inicial" (financiado) o "Pago al Contado" (contado) */
  get mostrarBotonPagoInicial(): boolean {
    if (this.esFinanciado) return this.inicialNum > 0;
    // Contado: se cobra el monto total al contado
    return this.montoTotalNum > 0;
  }

  /** ¿Ya está configurado el pago inicial? */
  get pagoInicialConfigurado(): boolean {
    return !!(this.pagoInicialRequest.tipoComprobante);
  }

  get cuotaMensual(): number {
    const s = this.saldoNum, l = this.cantidadLetrasNum;
    return l > 0 ? Math.floor(s / l) : 0;
  }
  get ultimaLetra(): number {
    const s = this.saldoNum, l = this.cantidadLetrasNum;
    if (l <= 0) return 0;
    return s - Math.floor(s / l) * (l - 1);
  }
  get tieneResiduo(): boolean { return this.ultimaLetra !== this.cuotaMensual; }

  /** ¿Se requiere N° de operación? (todo excepto efectivo) */
  get requiereNumeroOperacion(): boolean {
    return this.pagoInicialRequest.medioPago !== MedioPago.EFECTIVO;
  }

  /** ¿Se requiere voucher? */
  get requiereVoucher(): boolean {
    return this.pagoInicialRequest.medioPago !== MedioPago.EFECTIVO &&
           this.pagoInicialRequest.medioPago !== null &&
           this.pagoInicialRequest.medioPago !== undefined;
  }

  constructor(
    private fb: FormBuilder,
    private contratoService: ContratoService,
    private programaService: ProgramaService,
    private vendedorService: VendedorService,
    private clienteService: ClienteService,
    private separacionService: SeparacionService,
    private loteService: LoteService,
    public router: Router,
    private route: ActivatedRoute,
    private toastr: ToastrService,
    private tipoCambioService: TipoCambioService,
    private pagoLetraService: PagoLetraService,
    private tokenSvc: TokenService
  ) {}

  get esSoporte(): boolean {
    return this.tokenSvc.getRole() === 'ROLE_SOPORTE';
  }

  @HostListener('document:click', ['$event'])
  onClick(event: MouseEvent): void {
    const t = event.target as HTMLElement;
    if (this.vendedorBusquedaContainer && !this.vendedorBusquedaContainer.nativeElement.contains(t)) this.mostrarVendedores = false;
    if (this.programaBusquedaContainer && !this.programaBusquedaContainer.nativeElement.contains(t)) this.mostrarProgramas = false;
    if (this.clienteBusquedaContainer && !this.clienteBusquedaContainer.nativeElement.contains(t)) this.mostrarClientes = false;
    if (this.loteBusquedaContainer && !this.loteBusquedaContainer.nativeElement.contains(t)) this.mostrarLotes = false;
  }

  ngOnInit(): void {
    this.initForm();
    this.cargarCombos();
    this.cargarClientesIniciales();
    this.handleFormChanges();
    this.cargarDatosTransferencia();
    this.cargarTipoCambio();
  }

  cargarTipoCambio(): void {
    this.tipoCambioService.obtenerTipoCambio().subscribe({
      next: (tc) => { this.tipoCambioEmpresa = tc.empresa; this.tipoCambioCompra = tc.compra; },
      error: () => { this.tipoCambioEmpresa = 0; this.tipoCambioCompra = 0; }
    });
  }

  onMonedaChange(): void {
    this.calcularMontoTotalLotes();
    this.saldoDisplay = this.formatearMoneda(this.saldoNum);
  }

  // ── MODAL PAGO INICIAL ────────────────────────────────────────────────

  private resetPagoInicial(): PagoInicialRequestDTO {
    return {
      importePagado: 0,
      fechaPago: obtenerFechaPeru(),
      fechaOperacion: '',
      horaOperacion: null,
      medioPago: null,
      numeroOperacion: null,
      observaciones: null,
      tipoComprobante: null,
      numeroComprobantePersonalizado: null,
    };
  }

  abrirModalPagoInicial(): void {
    // Prellenar con datos del formulario: inicial (financiado) o monto total (contado)
    this.pagoInicialRequest.importePagado = this.esFinanciado ? this.inicialNum : this.montoTotalNum;

    // Autogenerar observación
    const loteStr = this.lotesSeleccionados.length > 0
      ? this.lotesSeleccionados.map(l => `Mz. ${l.manzana} Lt. ${l.numeroLote}`).join(', ')
      : 'Mz. ___ Lt. ___';
    const programa = this.filtroPrograma || '___';
    const prefijoObs = this.esFinanciado ? 'Pago de Inicial de la' : 'Pago al contado de la';
    this.pagoInicialRequest.observaciones = `${prefijoObs} ${loteStr} del Programa ${programa}`;

    this.mostrarModalPagoInicial = true;
  }

  cerrarModalPagoInicial(): void {
    this.mostrarModalPagoInicial = false;
  }

  onTipoComprobanteInicialChange(): void {
    this.numeroComprobanteInicialPreview = '';
    this.modoManualComprobanteInicial = false;
    this.numeroComprobanteInicialManual = '';
    this.pagoInicialRequest.numeroComprobantePersonalizado = null;

    if (this.pagoInicialRequest.tipoComprobante) {
      this.cargandoPreviewInicial = true;
      this.pagoLetraService.previewSiguienteNumeroComprobante(this.pagoInicialRequest.tipoComprobante).subscribe({
        next: (numero) => {
          this.numeroComprobanteInicialPreview = numero;
          this.cargandoPreviewInicial = false;
        },
        error: () => { this.cargandoPreviewInicial = false; }
      });
    }
  }

  toggleModoManualInicial(): void {
    this.modoManualComprobanteInicial = !this.modoManualComprobanteInicial;
    if (!this.modoManualComprobanteInicial) {
      // Volver a automático
      this.numeroComprobanteInicialManual = '';
      this.pagoInicialRequest.numeroComprobantePersonalizado = null;
    }
  }

  onNumeroManualInicialChange(event: Event): void {
    const val = (event.target as HTMLInputElement).value;
    this.numeroComprobanteInicialManual = val;
    this.pagoInicialRequest.numeroComprobantePersonalizado = val || null;
  }

  onMedioPagoInicialChange(): void {
    if (this.pagoInicialRequest.medioPago === MedioPago.EFECTIVO) {
      this.pagoInicialRequest.numeroOperacion = null;
      this.pagoInicialRequest.fechaOperacion = '';
      this.voucherInicialFiles = [];
      this.limpiarOcrInicial();
    } else if (!this.pagoInicialRequest.fechaOperacion) {
      this.pagoInicialRequest.fechaOperacion = obtenerFechaPeru();
    }
  }

  /**
   * Recibe los datos extraídos por OCR de cada voucher del pago inicial.
   * Acumula los N° de operación (separados por coma) y conserva la fecha más alta.
   */
  onVoucherOcr(data: VoucherOcrData): void {
    console.log('[OCR Pago Inicial] Datos extraídos:', data);

    const cambios: string[] = [];

    if (data.numeroOperacion && data.fileName) {
      this.ocrOperationNumbers.set(data.fileName, data.numeroOperacion);
      this.actualizarNumeroOperacionInicial();
      cambios.push(`N° operación: ${data.numeroOperacion}`);
    }

    if (data.fechaPago && data.fileName) {
      this.ocrVoucherFechas.set(data.fileName, data.fechaPago);
      this.actualizarFechaInicial();
      cambios.push(`Fecha op: ${data.fechaPago}`);
    }

    if (data.horaOperacion && data.fileName) {
      this.ocrVoucherHoras.set(data.fileName, data.horaOperacion);
      this.actualizarFechaInicial();
      cambios.push(`Hora op: ${data.horaOperacion}`);
    }

    if (cambios.length > 0) {
      this.toastr.info(
        `Detectado (${data.confidence.toFixed(0)}% conf.): ${cambios.join(' | ')}`,
        'OCR'
      );
    } else {
      this.toastr.warning(
        `No se pudo extraer N° operación ni fecha del voucher "${data.fileName ?? ''}". Llénalos manualmente.`,
        'OCR'
      );
    }
  }

  /** Al quitar/agregar vouchers se limpian los datos OCR de los que ya no están. */
  onVoucherInicialFilesChange(files: File[]): void {
    const nombresActuales = new Set(files.map(f => f.name));
    for (const fileName of this.ocrOperationNumbers.keys()) {
      if (!nombresActuales.has(fileName)) this.ocrOperationNumbers.delete(fileName);
    }
    for (const fileName of this.ocrVoucherFechas.keys()) {
      if (!nombresActuales.has(fileName)) this.ocrVoucherFechas.delete(fileName);
    }
    for (const fileName of this.ocrVoucherHoras.keys()) {
      if (!nombresActuales.has(fileName)) this.ocrVoucherHoras.delete(fileName);
    }
    if (files.length === 0) {
      this.ocrFechaOperacion = null;
      this.ocrHoraOperacion = null;
    }
    this.actualizarNumeroOperacionInicial();
    this.actualizarFechaInicial();
  }

  private actualizarNumeroOperacionInicial(): void {
    const numeros = Array.from(this.ocrOperationNumbers.values());
    this.pagoInicialRequest.numeroOperacion = numeros.length > 0 ? numeros.join(', ') : null;
  }

  private actualizarFechaInicial(): void {
    const entries = Array.from(this.ocrVoucherFechas.entries());
    if (entries.length === 0) return;
    const maxEntry = entries.reduce((a, b) => (a[1] > b[1] ? a : b));
    this.pagoInicialRequest.fechaOperacion = maxEntry[1];
    this.ocrFechaOperacion = maxEntry[1];
    this.ocrHoraOperacion = this.ocrVoucherHoras.get(maxEntry[0]) ?? null;
  }

  private limpiarOcrInicial(): void {
    this.ocrOperationNumbers.clear();
    this.ocrVoucherFechas.clear();
    this.ocrVoucherHoras.clear();
    this.ocrFechaOperacion = null;
    this.ocrHoraOperacion = null;
  }

  confirmarPagoInicial(): void {
    // Validaciones básicas del modal
    if (!this.pagoInicialRequest.tipoComprobante) {
      this.toastr.warning('Seleccione el tipo de comprobante', 'Validación');
      return;
    }
    if (!this.pagoInicialRequest.medioPago) {
      this.toastr.warning('Seleccione el medio de pago', 'Validación');
      return;
    }
    if (!this.pagoInicialRequest.fechaPago) {
      this.toastr.warning('Ingrese la fecha de pago', 'Validación');
      return;
    }
    if (this.requiereNumeroOperacion && !this.pagoInicialRequest.numeroOperacion) {
      this.toastr.warning('Ingrese el N° de operación', 'Validación');
      return;
    }
    if (this.requiereNumeroOperacion && !this.pagoInicialRequest.fechaOperacion) {
      this.toastr.warning('La fecha de operación es obligatoria para este medio de pago', 'Validación');
      return;
    }

    // La hora del voucher solo aplica si la fecha de operación sigue siendo la detectada por OCR
    this.pagoInicialRequest.horaOperacion =
      this.ocrHoraOperacion && this.ocrFechaOperacion &&
        this.pagoInicialRequest.fechaOperacion === this.ocrFechaOperacion
        ? this.ocrHoraOperacion
        : null;

    this.cerrarModalPagoInicial();
    this.toastr.success('Datos del pago de inicial registrados', 'Listo');
  }

  // ── GUARDADO PRINCIPAL ─────────────────────────────────────────────────

  private cargarDatosTransferencia(): void {
    this.route.queryParams.subscribe(params => {
      if (params['transferencia'] !== '1') return;

      this.esTransferencia = true;
      this.idContratoOrigen = +params['idContratoOrigen'];

      const montoTotal    = +params['montoTotal'];
      const inicial       = +params['inicial'];
      const saldo         = +params['saldo'];
      const cantidadLetras = +params['cantidadLetras'];

      this.contratoForm.patchValue({
        tipoContrato:    'FINANCIADO',
        montoTotal:      montoTotal,
        inicial:         inicial,
        cantidadLetras:  cantidadLetras
      });

      this.contratoForm.get('saldo')?.setValue(saldo, { emitEvent: false });
      this.saldoDisplay = this.formatearMoneda(saldo);

      if (params['idVendedor']) {
        const idVendedor = +params['idVendedor'];
        this.vendedorService.listarVendedores().subscribe(vendedores => {
          const v = vendedores.find((v: any) => v.idVendedor === idVendedor);
          if (v) {
            this.contratoForm.get('vendedorId')?.setValue(v.idVendedor);
            this.filtroVendedor = `${v.nombre} ${v.apellidos}`;
          }
        });
      }

      if (params['idLotes']) {
        const ids: number[] = params['idLotes'].split(',').map(Number);
        ids.forEach(idLote => {
          this.loteService.obtenerLotePorId(idLote).subscribe({
            next: (lote: any) => {
              if (lote && !this.lotesSeleccionados.some(l => l.idLote === lote.idLote)) {
                this.lotesSeleccionados.push(lote);
                this.actualizarIdsLotes();
                if (this.lotesSeleccionados.length === 1 && lote.programa) {
                  this.contratoForm.get('idPrograma')?.setValue(lote.programa.idPrograma);
                  this.filtroPrograma = lote.programa.nombrePrograma;
                }
              }
            }
          });
        });
      }

      this.toastr.info(
        `Formulario pre-llenado desde contrato #${this.idContratoOrigen}. Asigne el nuevo cliente.`,
        'Transferencia'
      );
    });
  }

  private initForm() {
    this.contratoForm = this.fb.group({
      modalidadContrato: ['DIRECTO', Validators.required],
      tipoContrato: ['FINANCIADO', Validators.required],
      fechaContrato: [obtenerFechaPeru(), Validators.required],
      vendedorId: [null, Validators.required],
      idPrograma: [null, Validators.required],
      idSeparacion: [null],
      montoTotal: [0, [Validators.required, Validators.min(1)]],
      inicial: [0],
      saldo: [{ value: 0, disabled: true }],
      cantidadLetras: [null, [Validators.min(0)]],
      observaciones: [''],
      idClientes: [[], Validators.required],
      idLotes: [[], Validators.required],
      moneda: ['USD', Validators.required]
    });
  }

  private cargarCombos() {
    this.programaService.listarProgramas().subscribe(p => { this.programas = p; this.programasFiltrados = [...p]; });
    this.vendedorService.listarVendedores().subscribe(v => { this.vendedores = v; this.vendedoresFiltrados = [...v]; });
  }

  private handleFormChanges() {
    this.contratoForm.get('montoTotal')?.valueChanges.subscribe(() => this.actualizarSaldo());
      this.contratoForm.get('inicial')?.valueChanges.subscribe(() => {
      this.actualizarSaldo();
      if (this.inicialNum <= 0) {
        this.pagoInicialRequest = this.resetPagoInicial();
        this.voucherInicialFiles = [];
        this.limpiarOcrInicial();
      }
    });

    this.contratoForm.get('tipoContrato')?.valueChanges.subscribe(tipo => {
      if (tipo === 'CONTADO') {
        this.contratoForm.get('inicial')?.setValue(0, { emitEvent: false });
        this.contratoForm.get('cantidadLetras')?.setValue(0, { emitEvent: false });
        this.actualizarSaldo();
        this.pagoInicialRequest = this.resetPagoInicial();
        this.voucherInicialFiles = [];
        this.limpiarOcrInicial();
      }
      this.actualizarObservacion();
    });

    this.contratoForm.get('modalidadContrato')?.valueChanges.subscribe(modo => {
      const esSep = modo === 'SEPARACION';
      ['vendedorId', 'idPrograma', 'idClientes', 'idLotes'].forEach(f => {
        esSep ? this.contratoForm.get(f)?.clearValidators() : this.contratoForm.get(f)?.setValidators(Validators.required);
        this.contratoForm.get(f)?.updateValueAndValidity({ emitEvent: false });
      });
      if (esSep) {
        this.clientesSeleccionados = []; this.lotesSeleccionados = [];
        this.actualizarIdsClientes(); this.actualizarIdsLotes();
      } else {
        this.calcularMontoTotalLotes();
      }
    });

    this.contratoForm.get('idPrograma')?.valueChanges.subscribe(id => {
      if (!id) { this.lotes = []; this.lotesFiltrados = []; return; }
      this.loteService.listarLotesPorPrograma(id).subscribe(l => { this.lotes = l || []; this.lotesFiltrados = [...this.lotes]; });
    });
  }

  actualizarSaldo() {
    const saldo = Math.max(0, this.montoTotalNum - this.inicialNum);
    this.contratoForm.get('saldo')?.setValue(saldo, { emitEvent: false });
    this.saldoDisplay = this.formatearMoneda(saldo);
  }

  formatearMoneda(v: number): string {
    const moneda = this.contratoForm?.get('moneda')?.value || this.monedaSeleccionada;
    const simbolo = moneda === 'PEN' ? 'S/ ' : '$ ';
    return simbolo + new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(v);
  }

  getLoteCostoUSD(lote: Lote): number {
    return Math.round((Number(lote.area) || 0) * (Number(lote.precioM2) || 0));
  }

  getLoteCosto(lote: Lote): number {
    const costoUSD = this.getLoteCostoUSD(lote);
    const moneda = this.contratoForm?.get('moneda')?.value || 'USD';
    if (moneda === 'PEN' && this.tipoCambioEmpresa > 0) {
      return Math.round(costoUSD * this.tipoCambioEmpresa);
    }
    return costoUSD;
  }

  private calcularMontoTotalLotes() {
    if (!this.esDirecto) return;
    const total = this.lotesSeleccionados.reduce((a, l) => a + this.getLoteCosto(l), 0);
    this.contratoForm.get('montoTotal')?.setValue(total);
    this.actualizarSaldo();
  }

  campoInvalido(campo: string): boolean {
    const c = this.contratoForm.get(campo);
    return !!(c && c.invalid && c.touched);
  }

  filtrarVendedores() {
    const f = this.filtroVendedor.toLowerCase();
    this.vendedoresFiltrados = this.vendedores.filter(v => `${v.nombre} ${v.apellidos}`.toLowerCase().includes(f) || v.dni?.includes(f));
    this.mostrarVendedores = true;
  }
  seleccionarVendedor(v: Vendedor) {
    this.contratoForm.get('vendedorId')?.setValue(v.idVendedor);
    this.filtroVendedor = `${v.nombre} ${v.apellidos}`;
    this.mostrarVendedores = false;
  }

  filtrarProgramas() {
    const f = this.filtroPrograma.toLowerCase();
    this.programasFiltrados = this.programas.filter(p => p.nombrePrograma.toLowerCase().includes(f));
    this.mostrarProgramas = true;
  }
  seleccionarPrograma(p: Programa) {
    this.contratoForm.get('idPrograma')?.setValue(p.idPrograma);
    this.filtroPrograma = p.nombrePrograma;
    this.mostrarProgramas = false;
    this.actualizarObservacion();
  }

  abrirListaClientes() {
    if (this.clientes.length === 0) {
      this.cargarClientesIniciales();
    }
    if (this.filtroCliente.trim().length < 2) {
      this.mostrarClientes = true;
      this.clientesFiltrados = this.clientes.filter(c => !this.clientesSeleccionados.some(s => s.idCliente === c.idCliente));
      return;
    }
    this.filtrarClientes();
  }

  private cargarClientesIniciales(): void {
    this.clienteService.listarClientesPaginado(0, 200).subscribe(p => {
      this.clientes = p.content;
      if (this.mostrarClientes && this.filtroCliente.trim().length < 2) {
        this.clientesFiltrados = this.clientes.filter(c => !this.clientesSeleccionados.some(s => s.idCliente === c.idCliente));
      }
    });
  }

  private generarObservacion(): string {
    const tipo = this.contratoForm.get('tipoContrato')?.value || '';
    const manzanas = this.lotesSeleccionados.map(l => `Mz. ${l.manzana} Lt. ${l.numeroLote}`);
    const loteStr = manzanas.length > 0 ? manzanas.join(', ') : 'Mz. ___ Lt. ___';
    const programa = this.filtroPrograma || '___';
    return `Se realizó un contrato ${tipo} de la ${loteStr} del Programa: ${programa}`;
  }

  private actualizarObservacion() {
    this.contratoForm.get('observaciones')?.setValue(this.generarObservacion(), { emitEvent: false });
  }

  filtrarClientes() {
    const f = this.filtroCliente.trim();
    if (f.length < 2) {
      this.mostrarClientes = true;
      this.clientesFiltrados = this.clientes.filter(c => !this.clientesSeleccionados.some(s => s.idCliente === c.idCliente));
      return;
    }
    this.clienteService.buscarClientesPorFiltro(f, /^\d+$/.test(f) ? 'documento' : 'nombres').subscribe(data => {
      this.clientesFiltrados = data.filter(c => !this.clientesSeleccionados.some(s => s.idCliente === c.idCliente));
      this.mostrarClientes = true;
    });
  }
  seleccionarCliente(c: Cliente) {
    if (!this.clientesSeleccionados.some(s => s.idCliente === c.idCliente)) {
      this.clientesSeleccionados.push({ ...c, tipoPropietario: TipoPropietario.TITULAR });
      this.actualizarIdsClientes();
    }
    this.filtroCliente = ''; this.clientesFiltrados = [];
    setTimeout(() => { this.mostrarClientes = false; }, 0);
  }
  eliminarCliente(id: number) {
    this.clientesSeleccionados = this.clientesSeleccionados.filter(c => c.idCliente !== id);
    this.actualizarIdsClientes();
  }
  cambiarRolCliente(id: number, rol: TipoPropietario) {
    const c = this.clientesSeleccionados.find(c => c.idCliente === id);
    if (c) { c.tipoPropietario = rol; this.actualizarIdsClientes(); }
  }
  private actualizarIdsClientes() {
    this.contratoForm.get('idClientes')?.setValue(this.clientesSeleccionados.map(c => c.idCliente));
  }
  private getClientesRequest(): ContratoClienteRequestDTO[] {
    return this.clientesSeleccionados.map(c => ({ idCliente: c.idCliente, tipoPropietario: c.tipoPropietario }));
  }

  filtrarLotes() {
    if (!this.contratoForm.get('idPrograma')?.value) { this.toastr.warning('Primero selecciona un programa', 'Atención'); return; }
    const f = this.filtroLote;
    this.lotesFiltrados = this.lotes.filter(l =>
      !this.lotesSeleccionados.some(s => s.idLote === l.idLote) &&
      loteCoincide(l, f));
    this.mostrarLotes = true;
  }
  seleccionarLote(l: Lote) {
    if (!l.programa) l.programa = { nombrePrograma: this.filtroPrograma } as Programa;
    this.lotesSeleccionados.push(l); this.actualizarIdsLotes(); this.calcularMontoTotalLotes();
    this.filtroLote = ''; this.filtrarLotes();
    this.actualizarObservacion();
    setTimeout(() => { this.mostrarLotes = false; }, 0);
  }
  eliminarLote(id?: number) {
    if (id === undefined) return;
    this.lotesSeleccionados = this.lotesSeleccionados.filter(l => l.idLote !== id);
    this.actualizarIdsLotes(); this.calcularMontoTotalLotes(); this.filtrarLotes();
    this.actualizarObservacion();
  }
  private actualizarIdsLotes() {
    this.contratoForm.get('idLotes')?.setValue(this.lotesSeleccionados.map(l => l.idLote!));
  }

  buscarSeparaciones(event: Event) {
    const termino = (event.target as HTMLInputElement).value;
    if (termino.trim().length > 0) {
      this.separacionService.buscarSeparaciones(termino).subscribe(seps => {
        this.separaciones = (seps || []).filter((v, i, a) => a.findIndex(t => t.id === v.id) === i);
        this.showSeparacionList = true;
      });
    } else this.showSeparacionList = false;
  }

  seleccionarSeparacion(sep: SeparacionDTO) {
    this.contratoForm.get('idSeparacion')?.setValue(sep.id);
    this.terminoBusquedaSeparacion = sep.text;
    this.showSeparacionList = false;
    this.separacionService.obtenerSeparacionPorId(sep.id!).subscribe({
      next: (res: any) => {
        if (!res) return;
        this.contratoForm.get('montoTotal')?.setValue(res.monto || 0);
        this.actualizarSaldo();
        if (res.clientes?.length) {
          this.clientesSeleccionados = res.clientes
            .map((i: any) => i.cliente ? { ...i.cliente, tipoPropietario: i.tipoPropietario ?? TipoPropietario.TITULAR } : null)
            .filter(Boolean);
          this.actualizarIdsClientes();
        }
        if (res.lotes?.length) {
          this.lotesSeleccionados = res.lotes.map((i: any) => i.lote).filter(Boolean); this.actualizarIdsLotes();
          const prog = this.lotesSeleccionados[0]?.programa;
          if (prog) { this.contratoForm.get('idPrograma')?.setValue(prog.idPrograma); this.filtroPrograma = prog.nombrePrograma; }
        }
        if (res.vendedor) { this.contratoForm.get('vendedorId')?.setValue(res.vendedor.idVendedor); this.filtroVendedor = `${res.vendedor.nombre} ${res.vendedor.apellidos}`; }
        this.toastr.info('Separación cargada correctamente.');
      },
      error: () => this.toastr.error('No se pudieron cargar los detalles.')
    });
  }

  solicitarConfirmacion() {
    if (this.contratoForm.invalid) {
      this.contratoForm.markAllAsTouched();
      this.toastr.warning('Por favor completa todos los campos requeridos', 'Formulario incompleto');
      return;
    }
    // Si hay inicial > 0 en financiado, abrir el modal de pago en lugar del de confirmación
    if (this.mostrarBotonPagoInicial && !this.pagoInicialConfigurado) {
      this.abrirModalPagoInicial();
      return;
    }
    this.mostrarModalConfirmacion = true;
  }

  confirmarGuardado() {
    this.mostrarModalConfirmacion = false;
    this.isGuardando = true;
    const v = this.contratoForm.getRawValue();

    const request: ContratoRequestDTO = {
      fechaContrato: v.fechaContrato,
      tipoContrato: v.tipoContrato,
      montoTotal: Number(v.montoTotal) || 0,
      inicial: Number(v.inicial) || 0,
      saldo: Number(v.saldo) || 0,
      cantidadLetras: v.cantidadLetras,
      observaciones: v.observaciones,
      idVendedor: v.vendedorId,
      idSeparacion: v.idSeparacion,
      clientes: this.getClientesRequest(),
      idClientes: v.idClientes,
      idLotes: v.idLotes,
      moneda: v.moneda,
      pagoInicial: this.mostrarBotonPagoInicial && this.pagoInicialConfigurado
        ? { ...this.pagoInicialRequest }
        : null
    };

    this.contratoService.guardarContrato(request).subscribe({
      next: (res: any) => {
        this.idContratoGuardado = res?.idContrato ?? null;
        this.subirVouchersIniciales(res);
      },
      error: (err) => {
        this.isGuardando = false;
        this.toastr.error(err.error?.message || 'Error al guardar el contrato');
      }
    });
  }

  /** Sube todos los vouchers del pago inicial (secuencialmente) y finaliza el guardado. */
  private subirVouchersIniciales(res: any): void {
    const idContrato = this.idContratoGuardado;
    if (!idContrato || this.voucherInicialFiles.length === 0) {
      this.finalizarGuardado(res);
      return;
    }
    const files = [...this.voucherInicialFiles];
    let idx = 0;
    const siguiente = () => {
      if (idx >= files.length) {
        this.finalizarGuardado(res);
        return;
      }
      const file = files[idx++];
      this.contratoService.subirVoucherInicial(idContrato, file).subscribe({
        next: () => siguiente(),
        error: () => {
          this.toastr.warning(`No se pudo subir "${file.name}", intenta luego.`, 'Voucher');
          siguiente();
        }
      });
    };
    siguiente();
  }

  private finalizarGuardado(res: any): void {
    this.isGuardando = false;
    this.toastr.success('Contrato guardado con éxito');
    if (res?.pagoInicial?.numeroComprobante) {
      this.toastr.info(
        `Comprobante de inicial emitido: ${res.pagoInicial.numeroComprobante}`,
        'Comprobante'
      );
      // Auto-abrir el comprobante PDF en pestaña nueva
      const idContrato = res?.idContrato;
      if (idContrato) {
        this.contratoService.descargarComprobanteInicial(idContrato).subscribe({
          next: (blob) => window.open(URL.createObjectURL(blob), '_blank'),
          error: () => this.toastr.warning('Contrato guardado. No se pudo abrir el comprobante automáticamente.', 'Aviso')
        });
      }
    }
    this.router.navigate(['/secretaria-menu/contratos']);
  }

  cancelarConfirmacion() { this.mostrarModalConfirmacion = false; }

  private resetFormulario() {
    this.monedaSeleccionada = 'USD';
    this.contratoForm.reset({ modalidadContrato: 'DIRECTO', tipoContrato: 'FINANCIADO', montoTotal: 0, inicial: 0, saldo: 0, cantidadLetras: null, moneda: 'USD' }, { emitEvent: false });
    this.clientesSeleccionados = []; this.lotesSeleccionados = []; this.separaciones = [];
    this.filtroVendedor = ''; this.filtroPrograma = ''; this.filtroCliente = ''; this.filtroLote = '';
    this.lotes = []; this.lotesFiltrados = []; this.showSeparacionList = false;
    this.terminoBusquedaSeparacion = ''; this.saldoDisplay = '$ 0.00';
    this.tipoCambioEmpresa = 0; this.tipoCambioCompra = 0;
    this.pagoInicialRequest = this.resetPagoInicial();
    this.voucherInicialFiles = [];
    this.limpiarOcrInicial();
  }

  abrirModalVendedor() { this.vendedorModalContrato.abrirModal(); }
  abrirModalCliente() { this.registroModal.abrirModalCliente(); }
  abrirModalPrograma() { this.registroModalPrograma.abrirModal(); }
  abrirModalLote() { this.loteModalContrato.abrirModal(); }

  recargarVendedores() { this.vendedorService.listarVendedores().subscribe(v => { this.vendedores = v; this.vendedoresFiltrados = [...v]; }); }
  RecargarClientes() { this.cargarClientesIniciales(); }
  RecargarProgramas() { this.programaService.listarProgramas().subscribe(p => { this.programas = p; this.programasFiltrados = [...p]; }); }
  RecargarLotes() {
    const id = this.contratoForm.get('idPrograma')?.value;
    if (id) this.loteService.listarLotesPorPrograma(id).subscribe(l => { this.lotes = l || []; this.filtrarLotes(); });
  }
}