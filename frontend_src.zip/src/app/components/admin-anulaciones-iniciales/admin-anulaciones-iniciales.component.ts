import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FlatpickrDirective } from '../../directives/flatpickr.directive';
import { AdminAnulacionesService, FiltrosAnulacion } from '../../services/admin-anulaciones.service';
import { PagoInicialResponseDTO } from '../../dto/pagoinicialresponse.dto';

// El backend devuelve el pago inicial enriquecido con datos del contrato
export interface PagoInicialAdminDTO extends PagoInicialResponseDTO {
  idContrato?: number;
  nombreCliente?: string;
  programa?: string;
  manzana?: string;
  lote?: string;
}

@Component({
  selector: 'app-admin-anulaciones-iniciales',
  standalone: true,
  imports: [CommonModule, FormsModule, FlatpickrDirective],
  templateUrl: './admin-anulaciones-iniciales.html',
  styleUrls: ['./admin-anulaciones-iniciales.scss']
})
export class AdminAnulacionesInicialesComponent implements OnInit {

  pagos: PagoInicialAdminDTO[] = [];
  pagosFiltrados: PagoInicialAdminDTO[] = [];
  cargando = false;

  filtros: FiltrosAnulacion = {};
  tipoComprobanteFiltro = '';
  fechaDesde?: string;
  fechaHasta?: string;

  @ViewChild('numeroComprobanteInput') numeroComprobanteInput?: ElementRef;

  // Al escoger Boleta o Recibo, prefill el N° de comprobante con la serie y foca
  onTipoComprobanteChange(): void {
    if (this.tipoComprobanteFiltro === 'B001') this.filtros.numeroComprobante = 'B001-';
    else if (this.tipoComprobanteFiltro === 'RB01') this.filtros.numeroComprobante = 'RB01-';
    else this.filtros.numeroComprobante = '';

    setTimeout(() => {
      const input = this.numeroComprobanteInput?.nativeElement as HTMLInputElement | undefined;
      if (input) {
        input.focus();
        const pos = input.value.length;
        input.setSelectionRange(pos, pos);
      }
    }, 0);
  }

  mostrarModalAnular = false;
  pagoSeleccionado?: PagoInicialAdminDTO;
  motivoAnulacion = '';
  procesando = false;

  mostrarModalNotaCredito = false;
  pagoNc?: PagoInicialAdminDTO;
  codMotivoNc = '01';
  desMotivoNc = '';
  procesandoNc = false;
  motivosNc: {[key: string]: string} = {};

  toast = { mostrar: false, mensaje: '', tipo: 'success' };

  constructor(private anulacionesService: AdminAnulacionesService) {}

  ngOnInit(): void { this.cargarPagos(); }

  cargarPagos(): void {
    this.cargando = true;
    this.anulacionesService.listarPagosIniciales(this.filtros).subscribe({
      next: (data) => {
        this.pagos = data as PagoInicialAdminDTO[];
        this.pagosFiltrados = this.pagos;
        this.cargando = false;
      },
      error: () => {
        this.mostrarNotificacion('Error al cargar pagos iniciales', 'error');
        this.cargando = false;
      }
    });
  }

  aplicarFiltros(): void {
    this.filtros.fechaDesde = this.fechaDesde || undefined;
    this.filtros.fechaHasta = this.fechaHasta || undefined;
    this.cargarPagos();
  }
  limpiarFiltros(): void { this.filtros = {}; this.tipoComprobanteFiltro = ''; this.fechaDesde = undefined; this.fechaHasta = undefined; this.cargarPagos(); }

  abrirModalAnular(pago: PagoInicialAdminDTO): void {
    this.pagoSeleccionado = pago;
    this.motivoAnulacion = '';
    this.mostrarModalAnular = true;
  }

  confirmarAnulacion(): void {
    if (!this.pagoSeleccionado?.idContrato || !this.motivoAnulacion.trim()) return;
    this.procesando = true;
    this.anulacionesService.anularPagoInicial(this.pagoSeleccionado.idContrato, this.motivoAnulacion).subscribe({
      next: () => {
        this.mostrarNotificacion('Pago inicial anulado correctamente', 'success');
        this.cerrarModalAnular();
        this.cargarPagos();
      },
      error: () => { this.mostrarNotificacion('Error al anular', 'error'); this.procesando = false; }
    });
  }

  cerrarModalAnular(): void {
    this.mostrarModalAnular = false;
    this.pagoSeleccionado = undefined;
    this.procesando = false;
  }

  puedeAnularConSunat(pago: PagoInicialAdminDTO): boolean {
    return !pago.anulado && !!pago.numeroComprobante && pago.numeroComprobante.startsWith('B');
  }

  abrirModalNotaCredito(pago: PagoInicialAdminDTO): void {
    this.pagoNc = pago;
    this.codMotivoNc = '01';
    this.desMotivoNc = '';
    this.procesandoNc = false;
    this.mostrarModalNotaCredito = true;
    if (Object.keys(this.motivosNc).length === 0) {
      this.anulacionesService.obtenerMotivosNotaCredito().subscribe({
        next: (m) => this.motivosNc = m,
        error: () => this.motivosNc = { '01': 'Anulacion de la operacion', '06': 'Devolucion total' }
      });
    }
  }

  confirmarNotaCredito(): void {
    if (!this.pagoNc || !this.desMotivoNc.trim()) return;
    this.procesandoNc = true;
    this.anulacionesService.enviarNotaCredito(
      this.pagoNc.idPagoInicial,
      'INICIAL',
      this.codMotivoNc,
      this.desMotivoNc
    ).subscribe({
      next: (res: any) => {
        this.mostrarNotificacion(res.mensaje || 'Nota de crédito emitida', 'success');
        this.cerrarModalNotaCredito();
        this.cargarPagos();
        if (res.idNotaCredito) {
          const obs = res.serieNC?.startsWith('BB')
            ? this.anulacionesService.descargarPdfNotaCredito(res.idNotaCredito)
            : this.anulacionesService.descargarPdfNotaCreditoRecibo(res.idNotaCredito);
          obs.subscribe({ next: (blob) => window.open(URL.createObjectURL(blob), '_blank') });
        }
      },
      error: (err) => {
        const msg = err.error?.error || 'Error al emitir nota de crédito';
        this.mostrarNotificacion(msg, 'error');
        this.procesandoNc = false;
      }
    });
  }

  cerrarModalNotaCredito(): void {
    this.mostrarModalNotaCredito = false;
    this.pagoNc = undefined;
    this.procesandoNc = false;
  }

  descargarComprobante(pago: PagoInicialAdminDTO): void {
    if (!pago.idContrato) return;
    this.anulacionesService.descargarComprobanteInicial(pago.idContrato).subscribe({
      next: (blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `comprobante-inicial-${pago.numeroComprobante || pago.idContrato}.pdf`;
        a.click();
        URL.revokeObjectURL(url);
      },
      error: () => this.mostrarNotificacion('Error al descargar comprobante', 'error')
    });
  }

  private descargarNc(idNc: number, serieNc: string | undefined): void {
    const obs = serieNc?.startsWith('BB')
      ? this.anulacionesService.descargarPdfNotaCredito(idNc)
      : this.anulacionesService.descargarPdfNotaCreditoRecibo(idNc);
    obs.subscribe({
      next: (blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.download = `nc-${idNc}.pdf`; a.href = url;
        a.click();
        URL.revokeObjectURL(url);
      },
      error: () => this.mostrarNotificacion('Error al descargar nota de crédito', 'error')
    });
  }

  descargarNotaCredito(pago: PagoInicialAdminDTO): void {
    if (pago.idComprobante) {
      this.anulacionesService.buscarNotaCreditoPorOriginal(pago.idComprobante).subscribe({
        next: (res) => {
          if (res.idNotaCredito) this.descargarNc(res.idNotaCredito, res.serie);
        },
        error: () => this.mostrarNotificacion('No se encontró nota de crédito', 'error')
      });
    }
  }

  mostrarNotificacion(mensaje: string, tipo: 'success' | 'error'): void {
    this.toast = { mostrar: true, mensaje, tipo };
    setTimeout(() => { this.toast.mostrar = false; }, 3500);
  }
}