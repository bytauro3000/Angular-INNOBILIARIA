import { Component, OnInit, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core'; 
import { CommonModule, CurrencyPipe, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router'; 
import Swal from 'sweetalert2';

import { SeparacionResumen } from '../../dto/separacionresumen.dto';
import { SeparacionService } from '../../services/separacion.service';

@Component({
  selector: 'app-separacion',
  standalone: true,
  imports: [
    CommonModule, 
    FormsModule, 
    RouterModule, 
    CurrencyPipe, 
    DatePipe
  ], 
  templateUrl: './separacion-crud.html',
  styleUrl: './separacion-crud.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SeparacionComponent implements OnInit {
  separaciones: SeparacionResumen[] = [];
  paginasSeparaciones: SeparacionResumen[] = [];

  pageSize = 6;
  currentPage = 1;
  totalPages = 0;
  filtroTexto = '';

  // 'todas' → secretaría (resumen general). 'mias' → vendedor logueado (solo sus separaciones).
  modo: 'todas' | 'mias' = 'todas';

  constructor(
    private separacionService: SeparacionService,
    private router: Router,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef 
  ) {}

  ngOnInit(): void {
    this.modo = (this.route.snapshot.data['modo'] === 'mias') ? 'mias' : 'todas';
    this.cargarDatos();
  }

  cargarDatos(): void {
    const obs = (this.modo === 'mias')
      ? this.separacionService.obtenerSeparacionesMias()
      : this.separacionService.obtenerSeparacionResumen();

    obs.subscribe({
      next: (data) => {
        this.separaciones = data;
        this.aplicarFiltro();
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error al cargar separaciones:', error);
        this.cdr.detectChanges();
      }
    });
  }

  get datosFiltrados(): SeparacionResumen[] {
    if (!this.filtroTexto.trim()) return this.separaciones;
    const term = this.filtroTexto.toLowerCase();
    return this.separaciones.filter(s =>
      s.clientes.some(c => c.nombreCompleto?.toLowerCase().includes(term)) ||
      s.clientes.some(c => c.numDoc?.includes(term)) ||
      s.nomVendedor?.toLowerCase().includes(term)
    );
  }

  aplicarFiltro(): void {
    this.currentPage = 1;
    this.actualizarPaginacion();
  }

  filtrar(): void {
    this.aplicarFiltro();
  }

  actualizarPaginacion(): void {
    const data = this.datosFiltrados;
    this.totalPages = Math.ceil(data.length / this.pageSize);
    const start = (this.currentPage - 1) * this.pageSize;
    this.paginasSeparaciones = data.slice(start, start + this.pageSize);
    this.cdr.detectChanges();
  }

  get paginas(): (number | string)[] {
    const pages: (number | string)[] = [];
    const total = this.totalPages;
    if (total <= 7) {
      for (let i = 1; i <= total; i++) pages.push(i);
    } else {
      pages.push(1);
      if (this.currentPage > 3) pages.push('...');
      const start = Math.max(2, this.currentPage - 1);
      const end = Math.min(total - 1, this.currentPage + 1);
      for (let i = start; i <= end; i++) pages.push(i);
      if (this.currentPage < total - 2) pages.push('...');
      pages.push(total);
    }
    return pages;
  }

  irPagina(n: number | string): void {
    if (typeof n === 'number') {
      this.currentPage = n;
      this.actualizarPaginacion();
    }
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.actualizarPaginacion();
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.actualizarPaginacion();
    }
  }

  mostrarCrear(): void {
    this.router.navigate([this.basePath + '/registrar']);
  }

  mostrarEditar(item: SeparacionResumen): void {
    this.router.navigate([this.basePath + '/editar', item.idSeparacion]);
  }

  private get basePath(): string {
    return this.modo === 'mias' ? '/vendedor-menu/separaciones' : '/secretaria-menu/separaciones';
  }

  eliminar(item: SeparacionResumen): void {
    const loteInfo = item.lotes.map(l => `Mz ${l.manzana} Lt ${l.numeroLote}`).join(', ');
    Swal.fire({
      title: '¿Estás seguro?',
      text: `Se eliminará la separación de: ${loteInfo}`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.isConfirmed) {
        this.separacionService.eliminarSeparacion(item.idSeparacion).subscribe({
          next: () => {
            Swal.fire('¡Eliminado!', 'Registro borrado con éxito.', 'success');
            this.cargarDatos();
          },
          error: () => {
            Swal.fire('Error', 'No se pudo eliminar el registro.', 'error');
          }
        });
      }
    });
  }
}
