// src/app/models/letra-cambio.model.ts
 
import { Contrato } from './contrato.model';
import { Moneda } from '../dto/moneda.enum';
import { EstadoLetra } from '../enums/estadoletra';
import { TipoComprobante } from '../enums/tipocomprobante';
import { Distrito } from './distrito.model';
 
 
export interface LetraCambio {
  idLetra: number;
  contrato: Contrato;
  distrito: Distrito;
  numeroLetra: string;
  fechaGiro: string;
  fechaVencimiento: string;
  importe: number;
  importeLetras?: string;
  estadoLetra?: EstadoLetra;
  fechaPago?: string;
  tipoComprobante?: TipoComprobante;
  numeroComprobante?: string;
  observaciones?: string;
  monedaContrato?: Moneda;
  esMultiple?: boolean;
  /** Saldo aún por pagar cuando la letra está en estado PARCIAL */
  saldoPendiente?: number;
}
 