import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService, LoginRequest } from '../login.service';
import { jwtDecode } from 'jwt-decode';
import { TokenService } from '../token.service';
import { IdleTimeoutService } from '../idle-timeout.service';
import { TokenRefreshService } from '../token-refresh.service';
import { ToastrService } from 'ngx-toastr';
import { Title } from '@angular/platform-browser';
import { EmpresaService } from '../../services/empresa.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrls: ['./login.scss']
})
export class LoginComponent implements OnInit {
  loginRequest: LoginRequest = {
    correo: '',
    contrasena: ''
  };
  recordar: boolean = false;
  verContrasena: boolean = false;

  constructor(
    private loginService: LoginService,
    private router: Router,
    private tokenService: TokenService,
    private idleTimeoutService: IdleTimeoutService,
    private toastr: ToastrService,
    private titleService: Title,
    private tokenRefreshService: TokenRefreshService,
    private empresaService: EmpresaService
  ) {}

  ngOnInit(): void {
    this.empresaService.obtenerEmpresa().subscribe(e => {
      this.titleService.setTitle('Iniciar Sesión | ' + (e?.nombreComercial || 'Inmobiliaria Ivan'));
    });
    const correoGuardado = localStorage.getItem('remembered_email');
    if (correoGuardado) {
      this.loginRequest.correo = correoGuardado;
      this.recordar = true;
    }
  }

  togglePassword(): void {
    this.verContrasena = !this.verContrasena;
  }

  onLogin(): void {
    this.tokenService.removeToken();

    this.loginService.login(this.loginRequest).subscribe({
      next: (response) => {
        if (this.recordar) {
          localStorage.setItem('remembered_email', this.loginRequest.correo);
        } else {
          localStorage.removeItem('remembered_email');
        }

        const token = response.token;
        this.tokenService.setToken(token);
        // El refresh token se guarda en cookie HttpOnly por el backend

        // Iniciar refresh proactivo del JWT antes de que expire
        this.tokenRefreshService.scheduleNext();

        // Iniciar control de inactividad (1 hora)
        this.idleTimeoutService.startWatching();

        const decodedToken: any = jwtDecode(token);
        const userRole = decodedToken.rol;

        this.toastr.success('¡Bienvenido al SGI!', 'Acceso Exitoso');

        switch (userRole) {
          case 'ROLE_SECRETARIA':
            this.router.navigate(['/secretaria-menu']);
            break;
          case 'ROLE_SOPORTE':
            this.router.navigate(['/seleccion-menu']);
            break;
          case 'ROLE_ADMINISTRADOR':
            this.router.navigate(['/admin-menu']);
            break;
          case 'ROLE_VENDEDOR':
            this.router.navigate(['/vendedor-menu']);
            break;
          default:
            this.router.navigate(['/']);
        }
      },
      error: (err) => {
        console.error('Login fallido:', err);
        this.toastr.error('Correo o contraseña incorrectos', 'Error de Acceso', {
          timeOut: 3000,
          progressBar: true,
          positionClass: 'toast-top-right'
        });
      }
    });
  }
}