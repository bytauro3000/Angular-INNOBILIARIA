import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ContratoResponseDTO } from '../dto/contratoreponse.dto';
import { TransferenciaResponseDTO } from '../dto/Transferenciaresponse.dto';
import { ContratoRequestDTO } from '../dto/contratorequest.dto';
import { environment } from '../../environments/environment'; // Importamos el environment para usar la URL base

@Injectable({
  providedIn: 'root'
})
export class ContratoService {

  private readonly apiUrl = `${environment.apiUrl}/api/contratos`;

  constructor(private http: HttpClient) { }

  private getHeaders(): HttpHeaders {
    return new HttpHeaders({
      'Content-Type': 'application/json'
    });
  }

  listarContrato(): Observable<ContratoResponseDTO[]> {
    return this.http.get<ContratoResponseDTO[]>(`${this.apiUrl}/listar`);
  }

  obtenerContratoPorId(id: number): Observable<ContratoResponseDTO> {
    return this.http.get<ContratoResponseDTO>(`${this.apiUrl}/${id}`);
  }

  buscarPorProgramaManzanaLote(idPrograma: number, manzana: string, numeroLote: string): Observable<ContratoResponseDTO> {
  const params = new HttpParams()
    .set('idPrograma', idPrograma.toString())
    .set('manzana', manzana)
    .set('numeroLote', numeroLote);

  return this.http.get<ContratoResponseDTO>(`${this.apiUrl}/buscar-por-lote`, { params });
}

  guardarContrato(request: ContratoRequestDTO): Observable<ContratoResponseDTO> {
    return this.http.post<ContratoResponseDTO>(`${this.apiUrl}/agregar`, request, { headers: this.getHeaders() });
  }

  actualizarContrato(id: number, request: ContratoRequestDTO): Observable<ContratoResponseDTO> {
    return this.http.put<ContratoResponseDTO>(`${this.apiUrl}/actualizar/${id}`, request, { 
      headers: this.getHeaders() 
    });
  }

  eliminarContrato(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/eliminar/${id}`);
  }

  //Método para descargar el PDF generado en el Backend
  imprimirContratoPdf(id: number): Observable<Blob> {
    const timestamp = new Date().getTime();
    return this.http.get(`${this.apiUrl}/${id}/imprimir?t=${timestamp}`, { 
      responseType: 'blob'
    });
  }

  // Cambiar estado del contrato manualmente (secretaria)
  cambiarEstado(id: number, estado: string): Observable<ContratoResponseDTO> {
    const params = new HttpParams().set('estado', estado);
    return this.http.patch<ContratoResponseDTO>(`${this.apiUrl}/${id}/estado`, null, { params });
  }

  // Registrar renuncia voluntaria del cliente
  registrarRenuncia(id: number): Observable<ContratoResponseDTO> {
    return this.http.patch<ContratoResponseDTO>(`${this.apiUrl}/${id}/renuncia`, null);
  }

  // Registrar transferencia — devuelve datos calculados para el nuevo contrato
  registrarTransferencia(id: number): Observable<TransferenciaResponseDTO> {
    return this.http.patch<TransferenciaResponseDTO>(`${this.apiUrl}/${id}/transferencia`, null);
  }
}