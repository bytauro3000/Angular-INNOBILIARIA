import { Routes } from '@angular/router';
import { LoginLayoutComponent } from './auth/login/login-layout.component';
import { authGuard } from './auth/auth.guard';

// Importacion de Mensajeria
import { MensajeriaComponent } from './components/mensajeria/mensajeria.component';

// Importa los componentes de menú
import { SecretariaMenuComponent } from './components/menu-secretaria/secretaria-menu.component';
import { SoporteMenuComponent } from './components/menu-soporte/soporte-menu.component';
import { AdminMenuComponent } from './components/menu-admin/admin-menu.component';

//Importa los dashboards para los menús
import { SecretariaDashboard } from './components/secretaria-dashboard/secretaria-dashboard';

//Clientes
import { ClientesComponent } from './components/cliente-listar/cliente-listar.component';
import { ClienteInsertarComponent } from './components/cliente-insertar/cliente-insertar.component';
import { ClienteEditarComponent } from './components/cliente-editar/cliente-editar.component';
import { ClienteVer } from './components/cliente-ver/cliente-ver';

//Contratos
import { ContratoListarComponent } from './components/contrato-listar/contrato-listar.component';
import { ContratoInsertarComponent } from './components/contrato-insertar/contrato-insertar.component';
import { ContratoEditarComponent } from './components/contrato-editar/contrato-editar.component';

//PAGO LETRAS
import { PagoletraListarComponent } from './components/pagoletra-listar/pagoletra-listar.component';
import { PagoletraInsertarComponent } from './components/pagoletra-insertar/pagoletra-insertar.component';    

// Separaciones
import { SeparacionComponent } from './components/separacion-crud/separacion-crud.component';
import { SeparacionInsertEdit } from './components/separacion-insert-edit/separacion-insert-edit'; 

// Servicios Basicos
import { LecturaPlanillaComponent } from './components/lectura-plantilla/lectura-plantilla.component';
import { RecibosListarComponent } from './components/recibos-listar/recibos-listar.component';

// Otros componentes
import { ParceleroComponent } from './components/parcelero/parcelero';
import { VendedorComponent } from './components/vendedor/vendedor';
import { ProgramaComponent } from './components/programa/programa';
import { LoteComponent } from './components/lote/lote.component';

// Dashboard y Letras
import { MenuSoportePrincipal } from './components/menu-soporte-principal/menu-soporte-principal';
import { LetracambioListarComponent } from './components/letracambio-listar/letracambios-listar.component';
import { LetracambioInsertarComponent } from './components/letracambio-insertar/letracambio-insertar.component';

export const routes: Routes = [
  { path: 'login', component: LoginLayoutComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full' },

  // Ruta para el menú de Secretaria
  {
    path: 'secretaria-menu',
    component: SecretariaMenuComponent,
    canActivate: [authGuard], 
    children: [
      // 🟢 DASHBOARD (Esta es la ruta que hace que aparezca al inicio)
      { path: '', component: SecretariaDashboard },

      // Clientes
      { path: 'clientes', component: ClientesComponent },
      { path: 'clientes/insertar', component: ClienteInsertarComponent },
      { path: 'clientes/editar/:id', component: ClienteEditarComponent },
      { path: 'clientes/ver/:id', component: ClienteVer },

      // Letras de Cambio
      { path: 'letras/listar/:idContrato', component: LetracambioListarComponent },
      { path: 'letras/insertar/:idContrato', component: LetracambioInsertarComponent },

      // 🟢 SEPARACIONES (Rutas añadidas)
      { path: 'separaciones', component: SeparacionComponent },
      { path: 'separaciones/registrar', component: SeparacionInsertEdit },
      { path: 'separaciones/editar/:id', component: SeparacionInsertEdit },

      // Contratos
      { path: 'contratos', component: ContratoListarComponent },
      { path: 'contratos/registrar', component: ContratoInsertarComponent },
      { path: 'contratos/editar/:id', component: ContratoEditarComponent },

      //PAGO LETRAS 
      { path: 'pagoletras', component: PagoletraListarComponent },
      { path: 'pagoletras/insertar', component: PagoletraInsertarComponent },

      // Otros
      { path: 'programas', component: ProgramaComponent },
      { path: 'vendedores', component: VendedorComponent },
      { path: 'lotes', component: LoteComponent },
      { path: 'parceleros', component: ParceleroComponent },

      //Servicios Basicos
      { path: 'servicios-basicos', component: LecturaPlanillaComponent },
      { path: 'servicios-basicos/listar', component: RecibosListarComponent },

      //ruta para mensajeria
      { path: 'mensajeria', component: MensajeriaComponent }
    ]
  },

  // Soporte Links
  { 
    path: 'soporte-menu', 
    component: SoporteMenuComponent,
    canActivate: [authGuard], 
    children: [
      { path: '', component: MenuSoportePrincipal }
    ]
  },
  
  { path: 'admin-menu',  
    component: AdminMenuComponent,
  canActivate: [authGuard],
 },
];